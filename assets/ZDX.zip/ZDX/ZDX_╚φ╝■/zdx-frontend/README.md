<<<<<<< HEAD
<<<<<<< HEAD

=======
>>>>>>> aa976677c160397a5a414d4bd288730c1951f907
# 智能 BI

This project is initialized with [智能 BI](https://pro.ant.design). Follow is the quick guide for how to use.

## Environment Prepare

Install `node_modules`:

```bash
npm install
```

or

```bash
yarn
```

## Provided Scripts

智能 BI provides some useful script to help you quick start and build with web project, code style check and test.

Scripts provided in `package.json`. It's safe to modify or add additional script:

### Start project

```bash
npm start
```

### Build project

```bash
npm run build
```

### Check code style

```bash
npm run lint
```

You can also use script to auto fix some lint error:

```bash
npm run lint:fix
```

### Test code

```bash
npm test
```

## More

<<<<<<< HEAD
# You can view full document on our [official website](https://pro.ant.design). And welcome any feedback in our [github](https://github.com/ant-design/ant-design-pro).

# ducky-bi-frontend

Ducky BI：基于 React + SpringBoot + AIGC 实现的智能数据分析平台

> > > > > > > ecaff364eac3f429cb09dce895b7c54dea10be5e
=======
You can view full document on our [official website](https://pro.ant.design). And welcome any feedback in our [github](https://github.com/ant-design/ant-design-pro).
=======
# ducky-bi-frontend
Ducky BI：基于React + SpringBoot + AIGC实现的智能数据分析平台
>>>>>>> ecaff364eac3f429cb09dce895b7c54dea10be5e
>>>>>>> aa976677c160397a5a414d4bd288730c1951f907
