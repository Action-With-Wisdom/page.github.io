﻿export default [
  {
    path: '/user',
    layout: false,
    routes: [
      { name: '登录', path: '/user/login', component: './User/Login' },
      { name: '注册', path: '/user/register', component: './User/Register' },
    ],
  },
  { path: '/welcome', name: '欢迎', icon: 'smile', component: './Welcome' },
  { path: '/data_collection', name: '数据收集与通信', icon: 'StockOutlined', component: './DataCollection' },
  { path: '/auto_decide', name: '车载端自主决策', icon: 'PushpinOutlined', component: './AutoDecide' },
  { path: '/drive_helper', name: '驾驶预警辅助', icon: 'AlertOutlined', component: './DriveHelper' },
  { path: '/data_visualization', name: '智多行可视化', icon: 'barChart', component: './DataVisualization' },
  { path: '/vehicle_screen', name: '区域车辆筛选', icon: 'BorderHorizontalOutlined', component: './VehicleScreen' },
  { path: '/trajectory_predict', name: '车辆轨迹预测', icon: 'CompressOutlined', component: './TrajectoryPredict' },
  { path: '/collision_detect', name: '多车碰撞检测', icon: 'VideoCameraOutlined', component: './CollisionDetect' },
  { path: '/speed_Intersection', name: '路口车速索引', icon: 'ThunderboltOutlined', component: './CollisionDetect' },
  {
    path: '/admin',
    name: '管理页',
    icon: 'crown',
    access: 'canAdmin', // 只有管理员能访问
    //components:'./Admin',
    routes: [
      { path: '/admin/user-manager', name: '用户管理', component: './Admin/UserManager' },
      { path: '/admin/chart-manager', name: '图表管理', component: './Admin/ChartManager' },
      { path: '/admin', redirect: '/admin/sub-page' },
    ],
  },
  { path: '/', redirect: '/welcome' },
  { path: '*', layout: false, component: './404' },
];
