import React, { useState } from 'react';
import { Button, Image, Alert, Card, Row, Col } from 'antd';
import { CameraOutlined, WarningOutlined, CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';
import ReactECharts from 'echarts-for-react';

const AutonomousDecisionSystem = () => {
  const [warning, setWarning] = useState(null); // 用于显示预警信息

  // 模拟触发预警的函数
  const triggerWarning = () => {
    setWarning("请注意，车道已偏离！");
  };

  // ECharts 图表配置
  const echartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985'
        }
      }
    },
    xAxis: {
      type: 'category',
      data: ['A路口', 'B路段', 'C路段', 'D路口'],
      // name: '位置' // 设置 x 轴名称
    },
    yAxis: {
      type: 'value',
      // name: '流量' // 设置 y 轴名称
    },
    series: [{
      data: [120, 85, 150, 60],
      type: 'line'
    }]
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1>车载端自主决策系统</h1>
      <Row gutter={16}>
        <Col span={12}>
          {/* 实时路况数据展示 */}
          <Card title="实时路况数据（待补充）" style={{ marginBottom: '20px' }}>
            <ReactECharts option={echartsOption} style={{ height: '300px' }} />
          </Card>
          {/* 预警信息展示 */}
          <Card title="预警信息" style={{ marginBottom: '20px' }}>
            {warning ? (
              <Alert message={warning} type="warning" showIcon />
            ) : (
              <p>暂无预警信息</p>
            )}
            {/*<Button onClick={triggerWarning} style={{ marginTop: '10px' }}>手动触发预警</Button>*/}
          </Card>
        </Col>
        <Col span={12}>
          {/* 图像信息展示 */}
          <Card
            title="图像信息"
            style={{ marginBottom: '20px', textAlign: 'center' }}
            cover={<div style={{ margin: '0 auto' }}><Image width={400} src="https://th.bing.com/th/id/OIP.H2MuQT0oc1-ACoK1INgQ1wHaEK?w=237&h=180&c=7&r=0&o=5&dpr=1.3&pid=1.7
" alt="车载摄像头图像" /></div>}
          >
            <Button type="primary" icon={<CameraOutlined />}>打开摄像头</Button>
          </Card>
          {/* 系统状态信息 */}
          <Card title="系统状态" style={{ marginBottom: '20px' }}>
            <p><CheckCircleOutlined style={{ color: 'green', fontSize: '18px', marginRight: '8px' }} /> 连接状态：已连接</p>
            <p><CheckCircleOutlined style={{ color: 'green', fontSize: '18px', marginRight: '8px' }} /> 数据处理速度：正常</p>
            <p><CheckCircleOutlined style={{ color: 'green', fontSize: '18px', marginRight: '8px' }} /> 图像处理算法：运行中</p>
            <p><CloseCircleOutlined style={{ color: 'red', fontSize: '18px', marginRight: '8px' }} /> 预警类型：无</p>
            <p><CheckCircleOutlined style={{ color: 'green', fontSize: '18px', marginRight: '8px' }} /> 上次检测时间：2024-04-05 10:40:00</p>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default AutonomousDecisionSystem;
