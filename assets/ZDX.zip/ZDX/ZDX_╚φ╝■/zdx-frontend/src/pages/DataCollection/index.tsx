import { searchUsers } from '@/services/ant-design-pro/api';
import type { ActionType } from '@ant-design/pro-components';
import { ProTable } from '@ant-design/pro-components';
import {Button, Card, Col, Form, Image, Row, Select, Space, Spin, Upload} from 'antd';
import React, {useRef, useState} from 'react';
import TextArea from "antd/es/input/TextArea";
import {UploadOutlined} from "@ant-design/icons";
import ReactECharts from "echarts-for-react";
export const waitTimePromise = async (time: number = 100) => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(true);
    }, time);
  });
};

export const waitTime = async (time: number = 100) => {
  await waitTimePromise(time);
};
const columns: (
  | { dataIndex: string; valueType: string; width: number }
  | { dataIndex: string; title: string }
  | { dataIndex: string; title: string }
  | { dataIndex: string; title: string; render: (_, record) => JSX.Element }
  | { dataIndex: string; title: string }
  | { dataIndex: string; title: string }
  | { dataIndex: string; title: string }
  | {
  dataIndex: string;
  valueEnum: { '0': { text: string; status: string }; '1': { text: string; status: string } };
  filters: boolean;
  title: string;
}
  | {
  dataIndex: string;
  valueType: string;
  valueEnum: { '0': { text: string }; '1': { text: string } };
  title: string;
}
  | { dataIndex: string; valueType: string; title: string }
  | {
  valueType: string;
  title: string;
  render: (text, record, _, action) => JSX.Element[];
  key: string;
}
  )[] = [
  {
    dataIndex: 'id',
    valueType: 'indexBorder',
    width: 48,
  },
  {
    title: '时间戳',
    dataIndex: 'timestamp',
    valueType: 'dateTime',
  },
  {
    title: '车辆标识',
    dataIndex: 'vehicleId',
  },
  {
    title: '距离值/m',
    dataIndex: 'distanceValue',
  },
];

const data = [
  {
    id: 1,
    timestamp: '2024-04-05 10:30:00',
    vehicleId: 'V001',
    distanceValue: '5.2',
  },
  {
    id: 2,
    timestamp: '2024-04-05 10:31:00',
    vehicleId: 'V002',
    distanceValue: '6.8',
  },
  {
    id: 3,
    timestamp: '2024-04-05 10:32:00',
    vehicleId: 'V003',
    distanceValue: '4.5',
  },
  {
    id: 4,
    timestamp: '2024-04-05 10:33:00',
    vehicleId: 'V004',
    distanceValue: '7.3',
  },
  {
    id: 5,
    timestamp: '2024-04-05 10:34:00',
    vehicleId: 'V005',
    distanceValue: '3.6',
  },
  {
    id: 6,
    timestamp: '2024-04-05 10:35:00',
    vehicleId: 'V006',
    distanceValue: '9.1',
  },
  {
    id: 7,
    timestamp: '2024-04-05 10:36:00',
    vehicleId: 'V007',
    distanceValue: '4.8',
  },
  {
    id: 8,
    timestamp: '2024-04-05 10:37:00',
    vehicleId: 'V008',
    distanceValue: '6.5',
  },
  {
    id: 9,
    timestamp: '2024-04-05 10:38:00',
    vehicleId: 'V009',
    distanceValue: '8.2',
  },
  {
    id: 10,
    timestamp: '2024-04-05 10:39:00',
    vehicleId: 'V010',
    distanceValue: '5.9',
  },
];

const columns1 = [
  {
    dataIndex: 'id',
    valueType: 'indexBorder',
    width: 48,
  },
  {
    title: '时间戳',
    dataIndex: 'timestamp',
    valueType: 'dateTime',
  },
  {
    title: '车辆标识',
    dataIndex: 'vehicleId',
  },
  {
    title: '经度',
    dataIndex: 'longitude',
  },
  {
    title: '纬度',
    dataIndex: 'latitude',
  },
];
const data1 = [
  {
    id: 1,
    timestamp: '2024-04-05 10:30:00',
    vehicleId: 'V001',
    longitude: '120.123456',
    latitude: '30.987654',
  },
  {
    id: 2,
    timestamp: '2024-04-05 10:31:00',
    vehicleId: 'V002',
    longitude: '120.234567',
    latitude: '31.876543',
  },
  {
    id: 3,
    timestamp: '2024-04-05 10:32:00',
    vehicleId: 'V003',
    longitude: '120.345678',
    latitude: '32.765432',
  },
  {
    id: 4,
    timestamp: '2024-04-05 10:33:00',
    vehicleId: 'V004',
    longitude: '120.456789',
    latitude: '33.654321',
  },
  {
    id: 5,
    timestamp: '2024-04-05 10:34:00',
    vehicleId: 'V005',
    longitude: '120.567890',
    latitude: '34.543210',
  },
  {
    id: 6,
    timestamp: '2024-04-05 10:35:00',
    vehicleId: 'V006',
    longitude: '120.678901',
    latitude: '35.432109',
  },
  {
    id: 7,
    timestamp: '2024-04-05 10:36:00',
    vehicleId: 'V007',
    longitude: '120.789012',
    latitude: '36.321098',
  },
  {
    id: 8,
    timestamp: '2024-04-05 10:37:00',
    vehicleId: 'V008',
    longitude: '120.890123',
    latitude: '37.210987',
  },
  {
    id: 9,
    timestamp: '2024-04-05 10:38:00',
    vehicleId: 'V009',
    longitude: '120.901234',
    latitude: '38.109876',
  },
  {
    id: 10,
    timestamp: '2024-04-05 10:39:00',
    vehicleId: 'V010',
    longitude: '120.012345',
    latitude: '39.098765',
  },
];



//组件
export default () => {
  const actionRef = useRef<ActionType>();
  return (
    <Col>
      {/* 第一个 ProTable */}
      <Row>
        <ProTable
          columns={columns}
          cardBordered
          dataSource={data} // 使用模拟数据
          editable={{
            type: 'multiple',
          }}
          rowKey="id"
          search={{
            labelWidth: 'auto',
          }}
          options={{
            setting: {
              listsHeight: 400,
            },
          }}
          pagination={{
            pageSize: 10,
            onChange: (page) => console.log(page),
          }}
          dateFormatter="string"
          headerTitle={<div style={{ fontSize: '20px', fontWeight: 'bold', textAlign: 'center' }}>距离传感数据</div>}
        />
      </Row>

      {/* 第二个 ProTable */}
      <Row>
        <ProTable
          columns={columns1}
          cardBordered
          dataSource={data1} // 使用模拟数据
          editable={{
            type: 'multiple',
          }}
          rowKey="id"
          search={{
            labelWidth: 'auto',
          }}
          options={{
            setting: {
              listsHeight: 400,
            },
          }}
          pagination={{
            pageSize: 10,
            onChange: (page) => console.log(page),
          }}
          dateFormatter="string"
          headerTitle={<div style={{ fontSize: '20px', fontWeight: 'bold', textAlign: 'center' }}>位置传感数据</div>}
        />
      </Row>
    </Col>

  );
};
