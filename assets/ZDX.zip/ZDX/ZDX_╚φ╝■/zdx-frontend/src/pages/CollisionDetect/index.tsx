import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Button, Table, Space, notification } from 'antd';

// 模拟的车辆轨迹数据
const vehicleTrajectories = [
  { id: 1, longitude: 120.123, latitude: 30.456, speed: 60 },
  { id: 2, longitude: 120.130, latitude: 30.460, speed: 61 },
  // 其他车辆数据...
];

const CollisionDetectionSystem = () => {
  const [collisionDetected, setCollisionDetected] = useState(false); // 是否检测到碰撞
  const [collisionInfo, setCollisionInfo] = useState([]); // 碰撞信息

  // 模拟碰撞检测
  useEffect(() => {
    // 模拟碰撞检测逻辑，假设简单判断速度是否超过阈值来模拟碰撞检测
    const detected = vehicleTrajectories.some(vehicle => vehicle.speed > 80); // 假设速度超过80km/h即判断为碰撞
    setCollisionDetected(detected);
    if (detected) {
      // 发送预警信息
      notification.warning({
        message: '碰撞预警',
        description: '检测到多车可能发生碰撞，请注意安全！',
      });
    }
  }, []);

  // 模拟处理碰撞信息
  const handleCollisionInfo = () => {
    // 模拟处理碰撞信息的逻辑，这里简单地将所有车辆信息作为碰撞信息
    setCollisionInfo(vehicleTrajectories);
  };

  // 表格列配置
  const columns = [
    {
      title: '车辆编号',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: '经度',
      dataIndex: 'longitude',
      key: 'longitude',
    },
    {
      title: '纬度',
      dataIndex: 'latitude',
      key: 'latitude',
    },
    {
      title: '速度(km/h)',
      dataIndex: 'speed',
      key: 'speed',
    },
  ];

  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ marginBottom: '20px' }}>多车碰撞检测系统</h1>
      <Row gutter={[16, 16]}>
        <Col span={12}>
          <Card title="车辆轨迹信息" style={{ marginBottom: '20px' }}>
            <Table
              columns={columns}
              dataSource={vehicleTrajectories}
              pagination={false}
            />
          </Card>
        </Col>
        <Col span={12}>
          <Card title="碰撞检测结果" style={{ marginBottom: '20px' }}>
            {collisionDetected ? (
              <Button type="primary" onClick={handleCollisionInfo}>查看碰撞信息</Button>
            ) : (
              <p>未检测到碰撞</p>
            )}
          </Card>
          {collisionInfo.length > 0 && (
            <Card title="碰撞信息" style={{ marginBottom: '20px' }}>
              <Table
                columns={columns}
                dataSource={collisionInfo}
                pagination={false}
              />
            </Card>
          )}
        </Col>
      </Row>
    </div>
  );
};

export default CollisionDetectionSystem;
