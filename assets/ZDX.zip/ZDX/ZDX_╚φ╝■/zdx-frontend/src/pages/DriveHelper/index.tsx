import React, { useState } from 'react';
import { Button, Alert, Card, Row, Col, Modal } from 'antd';
import { WarningOutlined, CameraOutlined, CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';

const WarningAssistSystem = () => {
  const [warning, setWarning] = useState(null); // 预警信息状态
  const [modalVisible, setModalVisible] = useState(false); // 控制弹窗显示状态

  // 模拟触发预警的函数
  const triggerWarning = () => {
    setWarning("前方检测到障碍物，请注意避让！");
    setModalVisible(true); // 手动触发预警时显示预警弹窗
  };

  // 模拟自动减速的函数
  const handleAutoDecelerate = () => {
    // 在这里编写自动减速的逻辑
    console.log('自动减速');
  };

  // 模拟自动停车的函数
  const handleAutoStop = () => {
    // 在这里编写自动停车的逻辑
    console.log('自动停车');
  };

  // 模拟用户选择的操作
  const handleUserAction = (action) => {
    // 在这里根据用户选择的操作执行相应的逻辑
    console.log('用户选择了操作:', action);
    setModalVisible(false); // 关闭预警弹窗
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ marginBottom: '20px' }}>预警通告与驾驶辅助系统</h1>
      <Row gutter={[16, 16]}>
        {/* 车主信息 */}

        <Col span={12}>
          {/* 预警信息展示区域 */}
          <Card title="预警信息" style={{ marginBottom: '20px' }}>
            {warning ? (
              <>
                <Alert message={warning} type="warning" showIcon style={{ marginBottom: '10px', fontWeight: 'bold', fontSize: '16px' }} />
              </>
            ) : (
              <p>暂无预警信息</p>
            )}
            <Button onClick={triggerWarning}>手动触发预警</Button>
          </Card>

          {/* 驾驶辅助介入区域 */}
          <Card title="驾驶辅助介入" style={{ marginBottom: '20px' }}>
            {/* 自动减速 */}
            <Button type="primary" icon={<WarningOutlined />} onClick={handleAutoDecelerate} style={{ marginRight: '10px' }}>自动减速</Button>
            {/* 自动停车 */}
            <Button type="danger" icon={<CloseCircleOutlined />} onClick={handleAutoStop}>自动停车</Button>
          </Card>
          {/* 历史预警信息 */}
          <Card title="历史预警信息" style={{ marginBottom: '20px' }}>
            {/* 显示历史预警信息，可以根据需要填充 */}
            <p>2024-04-01 08:30: 前方车辆碰撞预警</p>
            <p>2024-03-31 12:15: </p>
            {/* 其他历史预警信息 */}
          </Card>
        </Col>
        <Col span={6}>
          {/* 车辆行驶数据 */}
          <Card title="车辆行驶数据" style={{ flex: 1, marginBottom: '20px', marginRight: '10px' }}>
          <p style={{ margin: '8px 0' }}>车速：60km/h</p>
            <p style={{ margin: '8px 0' }}>加速度：0.5m/s²</p>
            <p style={{ margin: '8px 0' }}>转速：3000rpm</p>
            <p style={{ margin: '8px 0' }}>燃油消耗率：7.5L/100km</p>
            <p style={{ margin: '8px 0' }}>油量：45L</p>
            <p style={{ margin: '8px 0' }}>行驶距离：120km</p>
            <p style={{ margin: '8px 0' }}>发动机温度：90℃</p>
            <p style={{ margin: '8px 0' }}>电池电量：80%</p>
            <p style={{ margin: '8px 0' }}>方向盘角度：20°</p>
            <p style={{ margin: '8px 0' }}>车辆位置：经度 120.123, 纬度 30.456</p>
            <p style={{ margin: '8px 0' }}>车辆方向：北</p>
            <p style={{ margin: '8px 0' }}>刹车状态：未踩下</p>
            <p style={{ margin: '8px 0' }}>转向灯状态：右转向灯</p>
            <p style={{ margin: '8px 0' }}>灯光状态：远光灯</p>
          </Card>
        </Col>
        <Col span={6}>
          {/* 道路环境数据 */}
          <Card title="道路环境数据" style={{ flex: 1, marginBottom: '20px', marginRight: '10px' }}>
          <p style={{ margin: '8px 0' }}>道路类型：城市道路</p>
            <p style={{ margin: '8px 0' }}>路况状况：干燥</p>
            <p style={{ margin: '8px 0' }}>道路标线：虚线</p>
            <p style={{ margin: '8px 0' }}>交通信号灯状态：绿灯</p>
            <p style={{ margin: '8px 0' }}>路口类型：十字路口</p>
            <p style={{ margin: '8px 0' }}>限速标志：60km/h</p>
            <p style={{ margin: '8px 0' }}>路面坡度：平坦</p>
            <p style={{ margin: '8px 0' }}>天气状况：晴天</p>
            <p style={{ margin: '8px 0' }}>能见度：良好</p>
            <p style={{ margin: '8px 0' }}>道路拥堵情况：畅通</p>
            <p style={{ margin: '8px 0' }}>道路宽度：5m</p>
          </Card>
        </Col>
      </Row>
      {/* 预警弹窗 */}
      <Modal
        title="预警提示"
        visible={modalVisible}
        onOk={() => handleUserAction('确认')}
        onCancel={() => handleUserAction('取消')}
        centered // 垂直居中显示
        footer={null} // 不显示默认的底部按钮
        bodyStyle={{ textAlign: 'center' }} // 文字居中显示
        width={400} // 设置弹窗宽度
        style={{ borderRadius: '10px' }} // 设置弹窗边框圆角
      >
        <h2 style={{ color: 'red' }}>紧急预警</h2>
        <p style={{ fontSize: '20px', fontWeight: 'bold' }}>{warning}</p>
        <div style={{ marginTop: '20px' }}>
          <Button type="primary" onClick={() => handleUserAction('自动减速')}>自动减速</Button>
          <Button style={{ marginLeft: '10px' }} onClick={() => handleUserAction('自动泊车')}>自动泊车</Button>
        </div>
      </Modal>
    </div>
  );
};

export default WarningAssistSystem;
