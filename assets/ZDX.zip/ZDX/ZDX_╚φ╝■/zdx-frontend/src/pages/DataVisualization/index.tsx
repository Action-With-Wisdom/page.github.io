import {listChartByPageUsingPOST} from '@/services/julii/chartController';
import {useModel} from '@umijs/max';
import {Alert, Button, Card, Col, Image, List, message, Modal, Row, Table} from 'antd';
import Search from 'antd/es/input/Search';
import ReactECharts from 'echarts-for-react';
import React, {useEffect, useState} from 'react';
import {CheckCircleTwoTone} from '@ant-design/icons';
import {ProTable} from "@ant-design/pro-table";

/**
 * 我的图表页面
 * @constructor
 *
 * @author Julii
 */
const AllChartPage: React.FC = () => {
  // 从全局状态中获取到当前用户的信息
  const {initialState} = useModel('@@initialState');
  const {currentUser} = initialState ?? {};

  // searchParams中的参数初始条件，提取出来便于后面恢复初始条件
  const initSearchParams = {
    current: 1, // 默认第一页
    pageSize: 10, // 每页展示四条数据
    sortField: 'createTime',
    sortOrder: 'desc',
  };

  // 要发送给后端的查询条件，在listMyChartByPageUsingPOST中可查看。这里是initSearchParams初始化搜索条件，后面的搜索条件更新时需要重置为它
  const [searchParams, setSearchParams] = useState<API.ChartQueryRequest>({...initSearchParams});

  // 存获取到的图表数据，类型为数据的返回值Chart
  const [chartList, setChartList] = useState<API.Chart[]>();

  // 因为是分页，需要拿到数据总数，类型为number,初始化为0
  const [total, setTotal] = useState<number>(0);

  // 加载状态，用来控制页面是否加载，默认为正在加载
  const [loading, setLoading] = useState<boolean>(true);
  const columns = [
    {
      dataIndex: 'id',
      key: 'id',
      valueType: 'indexBorder',
      width: 48,
      style: {color: 'red', fontWeight: 'bold'} // 添加样式
    },
    {
      title: '预警类型',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: '触发时间',
      dataIndex: 'triggerTime',
      key: 'triggerTime',
    },
    {
      title: '经度',
      dataIndex: 'longitude',
      key: 'longitude',
    },
    {
      title: '纬度',
      dataIndex: 'latitude',
      key: 'latitude',
    },
    {
      title: '速度',
      dataIndex: 'speed',
      key: 'speed',
    },
    {
      title: '探测范围',
      dataIndex: 'range',
      key: 'range',
    },
  ];

  const data = [
    {
      id: 1,
      type: '前方碰撞预警',
      triggerTime: '2024-04-01 08:30:00',
      vehicleId: 'V001',
      longitude: 120.12,
      latitude: 30.67,
      speed: 60,
      range: '100米',
    },
    {
      id: 2,
      type: '交叉路口碰撞预警',
      triggerTime: '2024-04-02 10:45:00',
      vehicleId: 'V002',
      longitude: 121.98,
      latitude: 31.98,
      speed: 50,
      range: '150米',
    },
    {
      id: 3,
      type: '基于信号灯状态的预警',
      triggerTime: '2024-04-03 14:20:00',
      vehicleId: 'V003',
      longitude: 121.35,
      latitude: 30.54,
      speed: 40,
      range: '200米',
    },
    {
      id: 4,
      type: '车道偏离预警',
      triggerTime: '2024-04-04 16:10:00',
      vehicleId: 'V004',
      longitude: 120.88,
      latitude: 30.12,
      speed: 45,
      range: '120米',
    },
    {
      id: 5,
      type: '变道预警',
      triggerTime: '2024-04-05 18:05:00',
      vehicleId: 'V005',
      longitude: 121.23,
      latitude: 30.98,
      speed: 55,
      range: '130米',
    },
    {
      id: 6,
      type: '超车预警',
      triggerTime: '2024-04-06 19:30:00',
      vehicleId: 'V006',
      longitude: 121.88,
      latitude: 30.23,
      speed: 65,
      range: '180米',
    },
    {
      id: 7,
      type: '前方碰撞预警',
      triggerTime: '2024-04-07 08:45:00',
      vehicleId: 'V007',
      longitude: 120.77,
      latitude: 30.42,
      speed: 55,
      range: '110米',
    },
    {
      id: 8,
      type: '车道偏离预警',
      triggerTime: '2024-04-08 10:15:00',
      vehicleId: 'V008',
      longitude: 121.12,
      latitude: 30.87,
      speed: 50,
      range: '120米',
    },
    {
      id: 9,
      type: '变道预警',
      triggerTime: '2024-04-09 12:30:00',
      vehicleId: 'V009',
      longitude: 121.55,
      latitude: 30.65,
      speed: 60,
      range: '130米',
    },
    {
      id: 10,
      type: '基于信号灯状态的预警',
      triggerTime: '2024-04-10 14:20:00',
      vehicleId: 'V010',
      longitude: 121.35,
      latitude: 30.54,
      speed: 40,
      range: '200米',
    },
    {
      id: 11,
      type: '超车预警',
      triggerTime: '2024-04-11 16:50:00',
      vehicleId: 'V011',
      longitude: 121.98,
      latitude: 30.78,
      speed: 70,
      range: '170米',
    },
    {
      id: 12,
      type: '交叉路口碰撞预警',
      triggerTime: '2024-04-12 18:05:00',
      vehicleId: 'V012',
      longitude: 120.98,
      latitude: 31.15,
      speed: 55,
      range: '140米',
    },
    {
      id: 13,
      type: '前方碰撞预警',
      triggerTime: '2024-04-13 19:30:00',
      vehicleId: 'V013',
      longitude: 121.23,
      latitude: 30.98,
      speed: 65,
      range: '150米',
    },
    {
      id: 14,
      type: '车道偏离预警',
      triggerTime: '2024-04-14 20:15:00',
      vehicleId: 'V014',
      longitude: 121.78,
      latitude: 30.42,
      speed: 45,
      range: '130米',
    },
    {
      id: 15,
      type: '变道预警',
      triggerTime: '2024-04-15 22:30:00',
      vehicleId: 'V015',
      longitude: 121.45,
      latitude: 30.65,
      speed: 55,
      range: '120米',
    },
    {
      id: 16,
      type: '基于信号灯状态的预警',
      triggerTime: '2024-04-16 23:20:00',
      vehicleId: 'V016',
      longitude: 120.88,
      latitude: 30.87,
      speed: 40,
      range: '180米',
    }
  ];
  const option = {
    "title": {
      "text": "预警类型分析",
      "left": "center"
    },
    "tooltip": {
      "trigger": "item",
      "formatter": "{a} <br/>{b}: {c} ({d}%)"
    },
    "legend": {
      "orient": "vertical",
      "left": 10,
      "data": ["前方碰撞预警", "交叉路口碰撞预警", "基于信号灯状态的预警", "车道偏离预警", "变道预警", "超车预警"]
    },
    "series": [
      {
        "name": "预警类型",
        "type": "pie",
        "radius": ["50%", "70%"],
        "avoidLabelOverlap": false,
        "label": {
          "show": false,
          "position": "center"
        },
        "emphasis": {
          "label": {
            "show": true,
            "fontSize": "30",
            "fontWeight": "bold"
          }
        },
        "labelLine": {
          "show": false
        },
        "data": [
          {"value": 10, "name": "前方碰撞预警"},
          {"value": 20, "name": "交叉路口碰撞预警"},
          {"value": 30, "name": "基于信号灯状态的预警"},
          {"value": 40, "name": "车道偏离预警"},
          {"value": 50, "name": "变道预警"},
          {"value": 60, "name": "超车预警"}
        ]
      }
    ]
  };
  const option1 = {
    "title": {
      "text": "触发时间分析",
      "left": "center",
    },
    "tooltip": {
      "trigger": "item",
      "formatter": function (params) {
        return params.name + ': ' + params.value;
      }
    },
    "radar": {
      "indicator": [
        {"name": "凌晨", "max": 20},
        {"name": "早晨", "max": 20},
        {"name": "上午", "max": 20},
        {"name": "中午", "max": 20},
        {"name": "下午", "max": 20},
        {"name": "晚上", "max": 20}
      ]
    },
    "series": [
      {
        "name": "触发时间分布",
        "type": "radar",
        "data": [
          {
            "value": [2, 5, 8, 12, 15, 10],
            "name": "预警触发次数"
          },
          {
            "value": [1, 3, 5, 8, 10, 6],
            "name": "前方碰撞预警"
          },
          {
            "value": [0, 1, 3, 5, 6, 4],
            "name": "交叉路口碰撞预警"
          },
          {
            "value": [0, 1, 2, 3, 4, 3],
            "name": "基于信号灯状态的预警"
          },
          {
            "value": [1, 2, 3, 4, 5, 4],
            "name": "车道偏离预警"
          },
          {
            "value": [0, 1, 2, 3, 4, 2],
            "name": "变道预警"
          },
          {
            "value": [1, 2, 3, 4, 5, 3],
            "name": "超车预警"
          }
        ]
      }
    ]
  };
  const option2 = {
    "title": {
      "text": "探测范围分析",
      "left": "center"
    },
    "tooltip": {
      "trigger": "axis",
      "axisPointer": {
        "type": "shadow"
      }
    },
    "grid": {
      "left": "15%",
      "right": "15%",
      "bottom": "15%",
      "containLabel": true
    },
    "xAxis": {
      "type": "category",
      "data": ["20米", "40米", "60米", "80米", "100米", "120米"],
      "axisTick": {
        "alignWithLabel": true
      },
      "axisLabel": {
        "rotate": 45
      }
    },
    "yAxis": {
      "type": "value",
      "name": "触发次数"
    },
    "series": [
      {
        "type": "bar",
        "barWidth": "50%", // 缩窄一点
        "data": [50, 80, 90, 70, 60, 85]
      }
    ]
  };










  const [showModal, setShowModal] = useState<boolean>(false); // 控制弹窗显示状态

  const [modalVisible, setModalVisible] = useState(false); // 控制弹窗显示状态

  // 模拟自动减速的函数
  const handleAutoDecelerate = () => {
    // 在这里编写自动减速的逻辑
    console.log('自动减速');
  };

  // 模拟自动停车的函数
  const handleAutoStop = () => {
    // 在这里编写自动停车的逻辑
    console.log('自动停车');
  };

  // 模拟用户选择的操作
  const handleUserAction = (action) => {
    // 在这里根据用户选择的操作执行相应的逻辑
    console.log('用户选择了操作:', action);
    setModalVisible(false); // 关闭预警弹窗
  };


  useEffect(() => {
    // 在页面加载后延迟2秒显示弹窗
    const timer = setTimeout(() => {
      setShowModal(true);
    }, 3000);

    // 清除定时器
    return () => clearTimeout(timer);
  }, []);

  const lodeData = async () => {
    // 获取数据中，页面还在加载中
    setLoading(true);

    // 要使用await语法就要使用async，await就是把异步变成同步，等后端返回结果之后才会执行后面的代码
    try {
      const res = await listChartByPageUsingPOST(searchParams);
      if (res.data) {
        // 获取数据成功后，将数据展示到前端，还需要一个定义变量来存图表数据
        setChartList(res.data.records ?? []); // 因为是数据列表，所以拿到records，数据为空，则传一个空数组
        // 数据总数
        setTotal(res.data.total ?? 0); // 为空的话为0
      } else {
        message.error('获取图表失败');
      }
    } catch (e: any) {
      message.error('获取所有图表失败' + e.message);
    }

    // 数据加载完毕
    setLoading(false);
  };

  // 在React首次页面渲染的时候以及数组中一些变量发生变化的时候触发加载数据
  useEffect(() => {
    lodeData();
  }, [searchParams]); // 这里添加一个依赖，搜索条件searchParams发生改变时，可以自动触发重新搜索

  return (
    <div className="my-chart-page">
      <div className="margin-16"/>
      <Row gutter={16}>
        <Col span={16}>
          <Card title="车主：智多行" style={{marginBottom: '20px'}}>
            <video width="100%" height="auto" controls controlsList="nodownload" style={{marginBottom: '0'}}>
              <source src="/4月10日.mp4" type="video/mp4"/>
            </video>
          </Card>
          <Card title="历史预警信息" style={{marginBottom: '20px'}}>
            <ProTable
              columns={columns}
              cardBordered
              dataSource={data}
              pagination={{pageSize: 10}}
            />
          </Card>
          <Card title="预警情况分析" style={{marginBottom: '20px'}}>
            <ReactECharts option={option} style={{height: '400px'}}/>
            <ReactECharts option={option1} style={{height: '400px'}}/>
            <ReactECharts option={option2} style={{height: '400px'}}/>
          </Card>
        </Col>
        <Col span={8}>
          <Card title="实时路况" style={{width: '100%', height: '140px'}}>
            <ul>
              <li>
                <CheckCircleTwoTone twoToneColor="#52c41a"
                                    style={{fontSize: '40px', marginRight: '8px', verticalAlign: 'middle'}}/>
                <span style={{fontSize: '20px', color: '#52c41a'}}>道路通畅，一路顺风！</span>
              </li>
            </ul>
          </Card>
          <List
            pagination={{
              onChange: (page, pageSize) => {
                // 当切换分页，在当前偶所条件的基础上，把页数调整为当前的页数
                setSearchParams({
                  ...searchParams,
                  current: page,
                  pageSize,
                });
              },
              current: searchParams.current, // 当前页数
              pageSize: searchParams.pageSize, // 页面参数
              total: total, // 页面总数
            }}
            loading={loading}
            dataSource={chartList}
            renderItem={(item) => (
              <List.Item key={item.id}>
                <Card style={{width: '100%', height: '300px'}}>
                  {/*<List.Item.Meta*/}
                  {/*  title={item.name}*/}
                  {/*/>*/}
                  <ReactECharts option={item.genChart && JSON.parse(item.genChart ?? '')}/>
                </Card>
              </List.Item>
            )}
          />
        </Col>
      </Row>
      <Modal
        title="预警提示"
        visible={showModal}
        onCancel={() => setShowModal(false)}
        onOk={() => setShowModal(false)}
        centered // 垂直居中显示
        bodyStyle={{ textAlign: 'center' }} // 文字居中显示
        // footer={null} // 不显示默认的底部按钮
      >
        <h2 style={{ color: 'red' }}>紧急预警</h2>
        <p style={{ fontSize: '20px', fontWeight: 'bold' }}>前方红灯，请谨慎驾驶！</p>
        {/*<div style={{ marginTop: '20px' }}>*/}
        {/*  <Button type="primary" onClick={() => handleUserAction('自动减速')}>自动减速</Button>*/}
        {/*  <Button style={{ marginLeft: '10px' }} onClick={() => handleUserAction('自动泊车')}>自动泊车</Button>*/}
        {/*</div>*/}
      </Modal>

    </div>
  );
};
export default AllChartPage;
