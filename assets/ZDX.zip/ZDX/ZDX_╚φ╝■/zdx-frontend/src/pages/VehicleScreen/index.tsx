import React, { useState } from 'react';
import { Input, Card, Col, Row, Table, Button } from 'antd';
import { ProTable } from "@ant-design/pro-components";

const RegionVehicleFilter = () => {
  const [selectedRegion, setSelectedRegion] = useState(''); // 用户选择的区域
  const [searchResult, setSearchResult] = useState([]); // 搜索结果

  // 模拟搜索和筛选功能
  const data = [
    { id: 1, name: '车辆1', longitude: '120.123', latitude: '30.456', speed: '60km/h', range: '200m' },
    { id: 2, name: '车辆2', longitude: '120.456', latitude: '30.789', speed: '50km/h', range: '180m' },
    { id: 3, name: '车辆3', longitude: '121.123', latitude: '31.456', speed: '55km/h', range: '190m' },
    { id: 4, name: '车辆4', longitude: '121.456', latitude: '31.789', speed: '65km/h', range: '220m' },
    { id: 5, name: '车辆5', longitude: '122.123', latitude: '32.456', speed: '70km/h', range: '250m' },
    { id: 6, name: '车辆6', longitude: '122.456', latitude: '32.789', speed: '75km/h', range: '270m' },
    { id: 7, name: '车辆7', longitude: '123.123', latitude: '33.456', speed: '80km/h', range: '300m' },
    { id: 8, name: '车辆8', longitude: '123.456', latitude: '33.789', speed: '85km/h', range: '320m' },
    { id: 9, name: '车辆9', longitude: '124.123', latitude: '34.456', speed: '90km/h', range: '350m' },
    { id: 10, name: '车辆10', longitude: '124.456', latitude: '34.789', speed: '95km/h', range: '370m' },
  ];

  // 表格列配置
  const columns = [
    {
      title: '车辆编号',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: '经度',
      dataIndex: 'longitude',
      key: 'longitude',
    },
    {
      title: '纬度',
      dataIndex: 'latitude',
      key: 'latitude',
    },
    {
      title: '速度',
      dataIndex: 'speed',
      key: 'speed',
    },
    {
      title: '探测范围',
      dataIndex: 'range',
      key: 'range',
    },
  ];

  // 处理搜索点击事件
  const handleSearch = () => {
    // 模拟搜索结果数据
    const result = [
      { id: 1, name: '车辆1', longitude: '120.123', latitude: '30.456', speed: '60km/h', range: '200m' },
      { id: 2, name: '车辆2', longitude: '120.123', latitude: '30.456', speed: '50km/h', range: '200m' },
      // 可以添加更多模拟数据
    ];
    setSearchResult(result);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ marginBottom: '20px' }}>区域车辆筛选系统</h1>
      <Row gutter={[16, 16]}>
        <Col span={12}>
          <Card title="筛选目标" style={{ marginBottom: '20px' }}>
            <Input.Group compact style={{ display: 'flex' }}>
              <Input style={{ flex: '1' }} placeholder="目标车辆位置" />
              <Input style={{ flex: '1' }} placeholder="筛选范围/m" />
              <Button type="primary" onClick={handleSearch}>搜索</Button>
            </Input.Group>
          </Card>
          {/* 区域选择 */}
          <Card title="区域地图" style={{ marginBottom: '20px' }}>
            <img src="/车辆搜索.jpg" alt="区域地图" style={{ marginTop: '10px', maxWidth: '100%', height: 'auto' }} />
          </Card>
        </Col>
        <Col span={12}>
          <Card title="筛选结果" style={{ marginBottom: '20px' }}>
            {searchResult.length > 0 ? (
              <Table
                columns={columns}
                cardBordered
                dataSource={searchResult} // 使用搜索结果数据
              />
            ) : (
              '请先输入筛选条件'
            )}
          </Card>
          {/* 车辆信息展示 */}
          <Card title="历史记录" style={{ marginBottom: '20px' }}>
            <Table
              columns={columns}
              cardBordered
              dataSource={data} // 使用模拟数据
            />
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default RegionVehicleFilter;
