import React, {useState} from 'react';
import {Input, Card, Col, Row, Table, Button, Spin} from 'antd';
import {ProTable} from "@ant-design/pro-components";

const RegionVehicleFilter = () => {
  const [selectedRegion, setSelectedRegion] = useState(''); // 用户选择的区域
  const [searchResult, setSearchResult] = useState([]); // 搜索结果
  const [loading, setLoading] = useState(false); // 加载状态

  // 模拟搜索和筛选功能
  const data = [
    { time: '08:00:00', longitude: '120.123', latitude: '30.456', speed: '60', direction: '90' },
    { time: '08:00:01', longitude: '120.130', latitude: '30.460', speed: '61', direction: '91' },
    { time: '08:00:02', longitude: '120.135', latitude: '30.465', speed: '62', direction: '92' },
    { time: '08:00:03', longitude: '120.140', latitude: '30.470', speed: '63', direction: '93' },
    { time: '08:00:04', longitude: '120.145', latitude: '30.475', speed: '64', direction: '94' },
    { time: '08:00:05', longitude: '120.150', latitude: '30.480', speed: '65', direction: '95' },
    { time: '08:00:06', longitude: '120.155', latitude: '30.485', speed: '66', direction: '96' },
    { time: '08:00:07', longitude: '120.160', latitude: '30.490', speed: '67', direction: '97' },
    { time: '08:00:08', longitude: '120.165', latitude: '30.495', speed: '68', direction: '98' },
    { time: '08:00:09', longitude: '120.170', latitude: '30.500', speed: '69', direction: '99' },
    { time: '08:00:10', longitude: '120.175', latitude: '30.505', speed: '70', direction: '100' },
    { time: '08:00:11', longitude: '120.180', latitude: '30.510', speed: '71', direction: '101' },
    { time: '08:00:12', longitude: '120.185', latitude: '30.515', speed: '72', direction: '102' },
    { time: '08:00:13', longitude: '120.190', latitude: '30.520', speed: '73', direction: '103' },
    { time: '08:00:14', longitude: '120.195', latitude: '30.525', speed: '74', direction: '104' },
    { time: '08:00:15', longitude: '120.200', latitude: '30.530', speed: '75', direction: '105' },
    { time: '08:00:16', longitude: '120.205', latitude: '30.535', speed: '76', direction: '106' },
    { time: '08:00:17', longitude: '120.210', latitude: '30.540', speed: '77', direction: '107' },
    { time: '08:00:18', longitude: '120.215', latitude: '30.545', speed: '78', direction: '108' },
    { time: '08:00:19', longitude: '120.220', latitude: '30.550', speed: '79', direction: '109' },
    { time: '08:00:20', longitude: '120.225', latitude: '30.555', speed: '80', direction: '110' },

  ];

  // 表格列配置
  const columns = [
    {
      title: '时间',
      dataIndex: 'time',
      key: 'time',
    },
    {
      title: '经度',
      dataIndex: 'longitude',
      key: 'longitude',
    },
    {
      title: '纬度',
      dataIndex: 'latitude',
      key: 'latitude',
    },
    {
      title: '速度(km/h)',
      dataIndex: 'speed',
      key: 'speed',
    },
    {
      title: '运行方向(°)',
      dataIndex: 'direction',
      key: 'direction',
    },
  ];

  // 处理搜索点击事件
  const handleSearch = () => {
    // 模拟搜索结果数据
    const result = [
      { time: '08:00:00', longitude: '120.123', latitude: '30.456', speed: '60', direction: '90' },
      { time: '08:00:01', longitude: '120.130', latitude: '30.460', speed: '61', direction: '91' },
      { time: '08:00:02', longitude: '120.135', latitude: '30.465', speed: '62', direction: '92' },
      { time: '08:00:03', longitude: '120.140', latitude: '30.470', speed: '63', direction: '93' },
      { time: '08:00:04', longitude: '120.145', latitude: '30.475', speed: '64', direction: '94' },
      { time: '08:00:05', longitude: '120.150', latitude: '30.480', speed: '65', direction: '95' },
      { time: '08:00:06', longitude: '120.155', latitude: '30.485', speed: '66', direction: '96' },
      { time: '08:00:07', longitude: '120.160', latitude: '30.490', speed: '67', direction: '97' },
      { time: '08:00:08', longitude: '120.165', latitude: '30.495', speed: '68', direction: '98' },
      { time: '08:00:09', longitude: '120.170', latitude: '30.500', speed: '69', direction: '99' },
      { time: '08:00:10', longitude: '120.175', latitude: '30.505', speed: '70', direction: '100' },
      { time: '08:00:11', longitude: '120.180', latitude: '30.510', speed: '71', direction: '101' },
      { time: '08:00:12', longitude: '120.185', latitude: '30.515', speed: '72', direction: '102' },
      { time: '08:00:13', longitude: '120.190', latitude: '30.520', speed: '73', direction: '103' },
      { time: '08:00:14', longitude: '120.195', latitude: '30.525', speed: '74', direction: '104' },
      { time: '08:00:15', longitude: '120.200', latitude: '30.530', speed: '75', direction: '105' },
      { time: '08:00:16', longitude: '120.205', latitude: '30.535', speed: '76', direction: '106' },
      { time: '08:00:17', longitude: '120.210', latitude: '30.540', speed: '77', direction: '107' },
      { time: '08:00:18', longitude: '120.215', latitude: '30.545', speed: '78', direction: '108' },
      { time: '08:00:19', longitude: '120.220', latitude: '30.550', speed: '79', direction: '109' },
      { time: '08:00:20', longitude: '120.225', latitude: '30.555', speed: '80', direction: '110' },
      // 可以添加更多模拟数据
    ];
    setSearchResult(result);
  };

  return (
    <div style={{padding: '20px'}}>
      <h1 style={{marginBottom: '20px'}}>区域车辆筛选系统</h1>
      <Row gutter={[16, 16]}>
        <Col span={12}>
          <Card title="预测目标" style={{marginBottom: '20px'}}>
            <Input.Group compact style={{display: 'flex'}}>
              <Input style={{flex: '1'}} placeholder="目标车辆"/>
              <Input style={{flex: '1'}} placeholder="周围车辆编号"/>
              <Button type="primary" onClick={handleSearch}>开始</Button>
            </Input.Group>
          </Card>
          {/* 区域选择 */}
          <Card title="预测路线" style={{marginBottom: '20px'}}>
            {loading ? (
              <Spin/> // 加载中显示加载效果
            ) : searchResult.length > 0 ? (
              <img src="/车辆轨迹预测.png" alt="区域地图" style={{marginTop: '10px', maxWidth: '100%', height: 'auto'}}/>
            ) : (
              '请先输入预测目标'
            )}
          </Card>
        </Col>
        <Col span={12}>
          <Card title="预测结果" style={{marginBottom: '20px'}}>
            {loading ? (
              <Spin/> // 加载中显示加载效果
            ) : searchResult.length > 0 ? (
              <Table
                columns={columns}
                cardBordered
                dataSource={searchResult} // 使用搜索结果数据
              />
            ) : (
              '请先输入预测目标'
            )}
          </Card>
        </Col>
      </Row>
    </div>
  );
};

export default RegionVehicleFilter;
