// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as chartController from './chartController';
import * as fileController from './fileController';
import * as postController from './postController';
import * as postFavourController from './postFavourController';
import * as postThumbController from './postThumbController';
import * as userController from './userController';
export default {
  chartController,
  fileController,
  postController,
  postFavourController,
  postThumbController,
  userController,
};
