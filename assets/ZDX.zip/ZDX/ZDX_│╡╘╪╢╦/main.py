import multiprocessing as mp
from multiprocessing import Process, Value, Array
#from distance.main import ct
from distance.main import TOF
from position.main import mpu6050
from IMU.main import N100N
#from sound.main import act
from sound.main import actpro
from communicate.main import sen
from interface.main import face
from interface.main import facepro
#from see.main import watch
#from signal.main import light


Identify = Value('i',-1) #控制开启哪一个模块 -1表示为空 0表示识别地图 1表示开启运动

If_distance = Value('i',0)    #-1 表示关闭状态 0 表示开启测距 1 代表正常测距
If_position = Value('i',0)    #-1 表示关闭状态 0 表示开启定位 1 代表正常定位
If_see = Value('i',0)         #-1 表示关闭状态 0 表示开启视觉 1 代表正常视觉
If_act = Value('i',0)         #-1 表示关闭状态 0 表示开启视觉 1 代表正常视觉
If_voice = Value('i',1) 
If_drive = Value('i',1) 
WtPrefer = Value('i',1) 

x_a = Value('i',0)        # x
y_a = Value('i',0)        # y
z_a = Value('i',0)        # z
x_v = Value('i',0)        # x
y_v = Value('i',0)        # y
z_v = Value('i',0)        # z
x_position = Value('i',0)        # x坐标
y_position = Value('i',0)        # y坐标
z_position = Value('i',0)        # z坐标

xspeed = Value('i',0)        # x坐标
yspeed = Value('i',0)        # y坐标
zspeed = Value('i',0)        # z坐标

sound_flag = Value('i',0)        # 音频调用 0 代表状态

Alarm = Value('i',6)   #预警模式 0 代表正常模式

sign = Value('i',0)    #转向灯状态 0 代表正常模式

ID = Value('i',0)

if __name__ == '__main__':
    
    #导航界面
    jiemian = mp.Process(target=facepro, args=(Alarm,x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position,xspeed,yspeed,zspeed,sign,If_voice,If_drive,WtPrefer))
    #jiemian = mp.Process(target=face, args=(Alarm,x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position,sign,If_voice,If_drive,WtPrefer))
    jiemian.start()
    
    #超声波差距数据获取
    ceju = mp.Process(target=TOF, args=(If_distance, Alarm))
    ceju.start()
    
    #位置传感器数据获取
    #weizhi = mp.Process(target=mpu6050, args=(If_position, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position))   
    weizhi = mp.Process(target=N100N, args=(If_position, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position))
    weizhi.start()
    
    # 视觉识别
    #shijue = mp.Process(target=watch, args=(Alarm,If_see))
    #shijue.start()
    
    #语音播报及智能车控制
    bobao = mp.Process(target=actpro, args=(Alarm,If_act,If_voice,If_drive,WtPrefer,xspeed,yspeed,zspeed))
    bobao.start()
    
    #转向灯控制及信息获取
    #deng = mp.Process(target=light, args=(sign))
    #deng.start()
    
    #服务器数据收发处理
    fa = mp.Process(target=sen, args=(Alarm, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position,sign))
    fa.start()
    

    jiemian.join()
    ceju.join()
    weizhi.join()
    #shijue.join()
    bobao.join()
    #deng.join()
