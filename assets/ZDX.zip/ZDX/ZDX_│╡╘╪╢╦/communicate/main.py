#coding:utf-8
#import necessary package
import socket
import time
import sys
import threading 

 
def generate_hex_frame(sender, receiver, ID, service_type, x_a,y_a,z_a,x_v,y_v,z_v,x_coord, y_coord, z_coord, indicator,tp):
    # Convert decimal values to hexadecimal strings
    sender_hex = hex(sender)[2:].zfill(2)
    receiver_hex = hex(receiver)[2:].zfill(2)
    ID_hex = hex(ID)[2:].zfill(4)
    tp_hex = hex(tp)[2:].zfill(2)
    service_type_hex = hex(service_type)[2:].zfill(2)
    x_a_hex = hex(x_a)[2:].zfill(4)
    y_a_hex = hex(y_a)[2:].zfill(4)
    z_a_hex = hex(z_a)[2:].zfill(4)
    x_v_hex = hex(x_v)[2:].zfill(4)
    y_v_hex = hex(y_v)[2:].zfill(4)
    z_v_hex = hex(z_v)[2:].zfill(4)
    x_coord_hex = hex(x_coord)[2:].zfill(4)
    y_coord_hex = hex(y_coord)[2:].zfill(4)
    z_coord_hex = hex(z_coord)[2:].zfill(4)
    indicator_hex = hex(indicator)[2:].zfill(2)
    
    # Construct the hex frame
    hex_frame ="ff" + sender_hex + receiver_hex + ID_hex + tp_hex+ service_type_hex + x_a_hex + y_a_hex + z_a_hex +x_v_hex + y_v_hex + z_v_hex +x_coord_hex + y_coord_hex + z_coord_hex + indicator_hex+ "00"+ "00"+ "00" + "fe"
    
    return hex_frame
 
def hex_to_ascii(hex_string):
    # Convert hexadecimal string to ASCII representation
    ascii_string = ''.join(chr(int(hex_string[i:i+2], 16)) for i in range(0, len(hex_string), 2))
    return ascii_string
    
def hex_to_binary(hex_string):
    # Convert hexadecimal string to binary representation
    binary_string = ''.join(format(int(hex_char, 16), '04b') for hex_char in hex_string)
    return binary_string
    
def hex_string_to_chars(hex_string):
    # Split the hexadecimal string into pairs of characters
    hex_pairs = [hex_string[i:i+2] for i in range(0, len(hex_string), 2)]
    # Convert each pair to corresponding character
    chars = [chr(int(pair, 16)) for pair in hex_pairs]
    return ''.join(chars)

def parse_hex_frame(hex_frame):
    # 验证帧头和帧尾
    if hex_frame[:2] != "ff" or hex_frame[-2:] != "fe":
        print("Invalid frame: Incorrect frame header or footer.")
        return None, None, None, None, None
    
    # 去除帧头 "FF" 和帧尾 "FE"
    hex_frame = hex_frame[2:-2]
    
    # 将帧分割成单独的字段
    sender = int(hex_frame[0:2], 16)  # 发送方
    receiver = int(hex_frame[2:4], 16)  # 接收方
    ID = int(hex_frame[4:8], 16)  # ID
    service_type = int(hex_frame[8:10], 16)  # 服务类型
    warning_info = int(hex_frame[10:12], 16)  # 预警信息
    
    return sender, receiver, ID, service_type, warning_info
    

 
###主循环
def sen(Alarm, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position,sign):
	HOST_IP = "172.20.10.3" #树莓派的IP地址
	HOST_PORT = 8888
	print("Starting socket: TCP...")
	#1.create socket object:socket=socket.socket(family,type)
	socket_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	print("TCP server listen @ %s:%d!" %(HOST_IP, HOST_PORT) )
	host_addr = (HOST_IP, HOST_PORT)
	#2.bind socket to addr:socket.bind(address)
	socket_tcp.bind(host_addr)
	#3.listen connection request:socket.listen(backlog)
	socket_tcp.listen(1)
	#4.waite for client:connection,address=socket.accept()
	socket_con, (client_ip, client_port) = socket_tcp.accept()
	print("Connection accepted from %s." %client_ip)
	socket_con.send("Welcome to RPi TCP server!".encode())
	print("Receiving package...")
	while True:
		sender = 1
		receiver = 4
		ID = 1234
		tp = 1
		service_type = 1
		x_A = x_a.value
		y_A = y_a.value
		z_A = z_a.value
		x_V = x_v.value
		y_V = y_v.value
		z_V = z_v.value
		x_coord = x_position.value
		y_coord = y_position.value
		z_coord = z_position.value
		indicator = sign.value
		hex_frame = generate_hex_frame(sender, receiver, ID, service_type, x_A,y_A,z_A,x_V,y_V,z_V,x_coord, y_coord, z_coord, indicator,tp)
		#hex_frame=hex_string_to_chars(hex_frame)
		socket_con.send(hex_frame.encode())		
		print(hex_frame)
		data=socket_con.recv(512)
		decoded_data = data.decode('ascii')
		print(decoded_data)
		sender, receiver, ID, service_type, warning_info = parse_hex_frame(decoded_data)
		if sender is not None:
			if warning_info>0:
				Alarm.value=warning_info
				print(warning_info)
				warning_info=0
				time.sleep(0.01)
		socket_con.send(data)
		time.sleep(0.01)

def rec(Alarm,ID):	
	HOST_IP = "172.20.10.3" #树莓派的IP地址
	HOST_PORT = 8888
	print("Starting socket: TCP...")
	#1.create socket object:socket=socket.socket(family,type)
	socket_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	print("TCP server listen @ %s:%d!" %(HOST_IP, HOST_PORT) )
	host_addr = (HOST_IP, HOST_PORT)
	#2.bind socket to addr:socket.bind(address)
	socket_tcp.bind(host_addr)
	#3.listen connection request:socket.listen(backlog)
	socket_tcp.listen(1)
	#4.waite for client:connection,address=socket.accept()
	socket_con, (client_ip, client_port) = socket_tcp.accept()
	print("Connection accepted from %s." %client_ip)
	socket_con.send("Welcome to RPi TCP server!".encode())
	print("Receiving package...")
	while True:
		data=socket_con.recv(512)
		decoded_data = data.decode('ascii')
		print(decoded_data)
		sender, receiver, ID, service_type, warning_info = parse_hex_frame(decoded_data)
		if sender is not None:
				#Alarm.value=warning_info
				print(warning_info)
				time.sleep(0.01)
		socket_con.send(data)
		#socket_tcp.close()

###主循环
def sent(Alarm, x_position,y_position,z_position,sign):
	HOST_IP = "172.20.10.3" #树莓派的IP地址
	HOST_PORT = 8888
	print("Starting socket: TCP...")
	#1.create socket object:socket=socket.socket(family,type)
	socket_tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	print("TCP server listen @ %s:%d!" %(HOST_IP, HOST_PORT) )
	host_addr = (HOST_IP, HOST_PORT)
	#2.bind socket to addr:socket.bind(address)
	socket_tcp.bind(host_addr)
	#3.listen connection request:socket.listen(backlog)
	socket_tcp.listen(1)
	#4.waite for client:connection,address=socket.accept()
	socket_con, (client_ip, client_port) = socket_tcp.accept()
	print("Connection accepted from %s." %client_ip)
	socket_con.send("Welcome to RPi TCP server!".encode())
	print("Receiving package...")
	while True:
		sender = 1
		receiver = 4
		ID = 1234
		tp = 1
		service_type = 1
		x_coord = 100
		y_coord = 100
		z_coord = 100
		indicator = 0
		hex_frame = generate_hex_frame(sender, receiver, ID, service_type, x_coord, y_coord, z_coord, indicator,tp)
		#hex_frame=hex_string_to_chars(hex_frame)
		socket_con.send(hex_frame.encode())		
		#print(hex_frame)
		data=socket_con.recv(512)
		decoded_data = data.decode('ascii')
		print(decoded_data)
		sender, receiver, ID, service_type, warning_info = parse_hex_frame(decoded_data)
		if sender is not None:
			if warning_info>0:
				#Alarm.value=warning_info
				print(warning_info)
				warning_info=0
				time.sleep(0.01)
		socket_con.send(data)
		time.sleep(0.01)
#sent(0,0,0,0,0)
