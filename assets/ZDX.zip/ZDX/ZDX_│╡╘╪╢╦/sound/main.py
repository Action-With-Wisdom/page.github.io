import pygame
import time
import RPi.GPIO as GPIO
import numpy as np
from serial import Serial
import binascii
import tkinter as tk

def calculate_bbc_checksum(data):
    checksum = 0
    # 处理十六进制字符串的每两个字符
    for i in range(0, len(data), 2):
        byte = int(data[i:i+2], 16)  # 转换为整数
        checksum ^= byte  # 异或运算

    # 转换为两个十六进制字符串，左侧补零
    checksum_hex = hex(checksum)[2:].zfill(2)
    
    return checksum_hex
def decimal_to_hex(decimal_num):
    if decimal_num < 0:
        decimal_num += 65536  # 对负数进行修正，假设数值范围为16位

    # 转化为二进制数（16位，包括符号位）
    binary_num = format(int(decimal_num), '016b')
    # 转化为十六进制数（4位）
    hex_num = hex(int(binary_num, 2))[2:].zfill(4)
    return hex_num

def change(speed_hex):
    speed_bin = bin(int(speed_hex, 16))[2:].zfill(16)  # 转换为二进制，并补齐到16位

    is_negative = int(speed_bin[0])  # 提取符号位

    if speed_bin[0] == '1':  # 判断符号位是否为1，表示负数
        complement = bin(int(speed_bin, 2) ^ 0xFFFF)[2:].zfill(16)  # 求得补码
        speed = -int(complement, 2) - 1  # 转换为十进制并赋予负号
    else:
        speed = int(speed_bin, 2)  # 符号位为0，直接转换为十进制

    return speed
def receive_data(ser):
    last_time = 0
    start_time = time.time()
    speeds = []
    flag = 1
    i = 0
    while flag:
        i+=1
        data = ser.read(1)  # 每次读取一个字节
        hex_data = data.hex()  # 转换为十六进制字符串
        if hex_data == '7b':
            msg = "7b"
            num = 1
            while True:
                data = ser.read(1)
                hex_data = data.hex()
                num += 1
                msg = msg+ " " + hex_data  # 将字节转换为整数类型并添加到消息中

                if num == 24:
                    if hex_data == '7d':
                        last_time = time.time() - start_time
                        data_list = msg.split(" ")  # 将字符串拆分为一个个十六进制数字
                        x_speed = change((data_list[2] + data_list[3]))/10
                        y_speed = change((data_list[4] + data_list[5]))/10
                        z_speed = change((data_list[6] + data_list[7]))/1000
                        # 将两个字节合并为一个十六进制数，然后再转化为十进制
                        speeds.append(x_speed) 
                        speeds.append(y_speed) 
                        speeds.append(z_speed) 
                        #x_speed = change(data_list[2] + data_list[3])
                        flag = 0
                    break
    return speeds,last_time
def check_hexadecimal_value(content):
    try:
        int(content, 16)  # 将字符串转换为十六进制数值
        return 0  # 字符串只包含十六进制数字，返回 0 表示通过检查
    except ValueError:
        return -1

def send_speed(speed,ser):
    content = '7b0000'
    if(speed[1] > 30000):
        speed[1] = 30000
    
    elif(speed[1] < -30000):
         speed[1] = -30000
    
    if(speed[2] > 30000):
        speed[2] = 30000
    elif(speed[2] < -30000):
         speed[2] = -30000
    
    x_hex = decimal_to_hex(int(speed[0]))
    y_hex = decimal_to_hex(int(speed[1]))
    z_hex = decimal_to_hex(int(speed[2]))
    content = content+str(x_hex)+str(y_hex)+str(z_hex)
    # 计算 BBC 校验结果
    checksum = calculate_bbc_checksum(content)
    content = content + checksum +'7d'
    if check_hexadecimal_value(content) == 0:
        byte_data = bytes.fromhex(content)
        ser.write(byte_data)


def act(Alarm,If_act,If_voice,If_drive,WtPrefer):
	pygame.mixer.init()
	sound=pygame.mixer.Sound('alarm.wav')
	sound0=pygame.mixer.Sound('0.WAV')
	sound11=pygame.mixer.Sound('11.WAV')
	sound12=pygame.mixer.Sound('12.WAV')
	sound2=pygame.mixer.Sound('2.WAV')
	sound31=pygame.mixer.Sound('31.WAV')
	sound32=pygame.mixer.Sound('32.WAV')
	sound33=pygame.mixer.Sound('33.WAV')
	sound41=pygame.mixer.Sound('41.WAV')
	sound42=pygame.mixer.Sound('42.WAV')
	sound43=pygame.mixer.Sound('43.WAV')
	sound44=pygame.mixer.Sound('44.WAV')

	bps=115200
	#连接下位机
	ser= Serial("/dev/ttyACM0",bps,timeout=0.5)#连接下位机
	if ser.isOpen():                           # 判断串口是否成功打开
			print("打开串口成功。") 
			print(ser.name)    # 输出串口号
	else:
			print("打开串口失败。")

	while True:
		alarm = Alarm.value
		voice = If_voice.value
		drive = If_drive.value
		prefer = WtPrefer.value
		If_act.value = 1
		if alarm ==6 :
			if voice == 1:
				sound0.play()
				st=time.time()
				a=0
				while (a<6):
					ed=time.time()
					a=ed-st
					if a>=6:
						sound0.stop()
			else:
				st=time.time()
				a=0
				while (a<6):
					ed=time.time()
					a=ed-st
			if drive == 1:
				send_speed([-200,0,0],ser)
				print("move")				
			Alarm.value = 0
			print(Alarm.value)
			
		if alarm ==11 :
			if voice == 1:
				sound11.play()
				st=time.time()
				a=0
				while (a<2.7):
					ed=time.time()
					a=ed-st
					if a>=2.7:
						sound11.stop()
			else:
				st=time.time()
				a=0
				while (a<2.7):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-100,0,0],ser)
					print("slow")
				elif prefer == 0:
					send_speed([0,0,0],ser)
					print("stop")
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==12 :
			if voice == 1:
				sound12.play()
				st=time.time()
				a=0
				while (a<1.6):
					ed=time.time()
					a=ed-st
					if a>=1.6:
						sound12.stop()
			else:
				st=time.time()
				a=0
				while (a<1.6):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-300,0,0],ser)
					print("fast")
				elif prefer == 0:
					send_speed([0,0,0],ser)
					print("stop")
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==2 :
			if voice == 1:
				sound2.play()
				st=time.time()
				a=0
				while (a<5.1):
					ed=time.time()
					a=ed-st
					if a>=5.1:
						sound2.stop()
			else:
				st=time.time()
				a=0
				while (a<5.1):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-100,0,0],ser)
					print("slow")					
				elif prefer == 0:
					send_speed([0,0,0],ser)
					print("stop")
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==31 :
			if voice == 1:
				sound31.play()
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
					if a>=2.6:
						sound31.stop()
			else:
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==32 :
			if voice == 1:
				sound32.play()
				st=time.time()
				a=0
				while (a<2.5):
					ed=time.time()
					a=ed-st
					if a>=2.5:
						sound32.stop()
			else:
				st=time.time()
				a=0
				while (a<2.5):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-100,0,0],ser)
					print("slow")					
				elif prefer == 0:
					send_speed([0,0,0],ser)
					print("stop")
			Alarm.value = 0
			print(Alarm.value)
			
		if alarm ==33 :
			if voice == 1:
				sound33.play()
				st=time.time()
				a=0
				while (a<2.1):
					ed=time.time()
					a=ed-st
					if a>=2.1:
						sound33.stop()
			else:
				st=time.time()
				a=0
				while (a<2.1):
					ed=time.time()
					a=ed-st
			if drive == 1:
				send_speed([0,0,0],ser)
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==41 :
			if voice == 1:
				sound41.play()
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
					if a>=1.4:
						sound41.stop()
			else:
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==42 :
			if voice == 1:
				sound42.play()
				st=time.time()
				a=0
				while (a<1.7):
					ed=time.time()
					a=ed-st
					if a>=1.7:
						sound42.stop
			else:
				st=time.time()
				a=0
				while (a<1.7):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==43 :
			if voice == 1:
				sound43.play()
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
					if a>=2.6:
						sound43.stop()
			else:
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==44 :
			if voice == 1:
				sound44.play()
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
					if a>=1.4:
						sound44.stop()
			else:
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==5 :
			if voice == 1:
				sound.play()
				st=time.time()
				a=0
				while (a<2):
					ed=time.time()
					a=ed-st
					if a>=2:
						sound.stop()
			else:
				st=time.time()
				a=0
				while (a<2):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

def actpro(Alarm,If_act,If_voice,If_drive,WtPrefer,xspeed,yspeed,zspeed):
	pygame.mixer.init()
	sound=pygame.mixer.Sound('alarm.wav')
	sound0=pygame.mixer.Sound('0.WAV')
	sound11=pygame.mixer.Sound('11.WAV')
	sound12=pygame.mixer.Sound('12.WAV')
	sound2=pygame.mixer.Sound('2.WAV')
	sound31=pygame.mixer.Sound('31.WAV')
	sound32=pygame.mixer.Sound('32.WAV')
	sound33=pygame.mixer.Sound('33.WAV')
	sound41=pygame.mixer.Sound('41.WAV')
	sound42=pygame.mixer.Sound('42.WAV')
	sound43=pygame.mixer.Sound('43.WAV')
	sound44=pygame.mixer.Sound('44.WAV')

	bps=115200
	#连接下位机
	ser= Serial("/dev/ttyACM0",bps,timeout=0.5)#连接下位机
	if ser.isOpen():                           # 判断串口是否成功打开
			print("打开串口成功。") 
			print(ser.name)    # 输出串口号
	else:
			print("打开串口失败。")

	while True:
		alarm = Alarm.value
		voice = If_voice.value
		drive = If_drive.value
		prefer = WtPrefer.value
		If_act.value = 1
		if alarm ==6 :
			if voice == 1:
				sound0.play()
				st=time.time()
				a=0
				while (a<6):
					ed=time.time()
					a=ed-st
					if a>=6:
						sound0.stop()
			else:
				st=time.time()
				a=0
				while (a<6):
					ed=time.time()
					a=ed-st
			if drive == 1:
				send_speed([-200,0,0],ser)
				xspeed.value=200
				yspeed.value=0
				zspeed.value=0
				print("move")				
			Alarm.value = 0
			print(Alarm.value)
			
		if alarm ==11 :
			if voice == 1:
				sound11.play()
				st=time.time()
				a=0
				while (a<2.7):
					ed=time.time()
					a=ed-st
					if a>=2.7:
						sound11.stop()
			else:
				st=time.time()
				a=0
				while (a<2.7):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-100,0,0],ser)
					xspeed.value=100
					yspeed.value=0
					zspeed.value=0
					print("slow")
				elif prefer == 0:
					send_speed([0,0,0],ser)
					xspeed.value=0
					yspeed.value=0
					zspeed.value=0
					print("stop")
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==12 :
			if voice == 1:
				sound12.play()
				st=time.time()
				a=0
				while (a<1.6):
					ed=time.time()
					a=ed-st
					if a>=1.6:
						sound12.stop()
			else:
				st=time.time()
				a=0
				while (a<1.6):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-300,0,0],ser)
					xspeed.value=300
					yspeed.value=0
					zspeed.value=0
					print("fast")
				elif prefer == 0:
					send_speed([0,0,0],ser)
					xspeed.value=0
					yspeed.value=0
					zspeed.value=0
					print("stop")
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==2 :
			if voice == 1:
				sound2.play()
				st=time.time()
				a=0
				while (a<5.1):
					ed=time.time()
					a=ed-st
					if a>=5.1:
						sound2.stop()
			else:
				st=time.time()
				a=0
				while (a<5.1):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-100,0,0],ser)
					xspeed.value=100
					yspeed.value=0
					zspeed.value=0
					print("slow")					
				elif prefer == 0:
					send_speed([0,0,0],ser)
					xspeed.value=0
					yspeed.value=0
					zspeed.value=0
					print("stop")
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==31 :
			if voice == 1:
				sound31.play()
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
					if a>=2.6:
						sound31.stop()
			else:
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==32 :
			if voice == 1:
				sound32.play()
				st=time.time()
				a=0
				while (a<2.5):
					ed=time.time()
					a=ed-st
					if a>=2.5:
						sound32.stop()
			else:
				st=time.time()
				a=0
				while (a<2.5):
					ed=time.time()
					a=ed-st
			if drive == 1:
				if prefer == 1:
					send_speed([-100,0,0],ser)
					xspeed.value=100
					yspeed.value=0
					zspeed.value=0
					print("slow")					
				elif prefer == 0:
					send_speed([0,0,0],ser)
					xspeed.value=0
					yspeed.value=0
					zspeed.value=0
					print("stop")
			Alarm.value = 0
			print(Alarm.value)
			
		if alarm ==33 :
			if voice == 1:
				sound33.play()
				st=time.time()
				a=0
				while (a<2.1):
					ed=time.time()
					a=ed-st
					if a>=2.1:
						sound33.stop()
			else:
				st=time.time()
				a=0
				while (a<2.1):
					ed=time.time()
					a=ed-st
			if drive == 1:
				send_speed([0,0,0],ser)
				xspeed.value=0
				yspeed.value=0
				zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==41 :
			if voice == 1:
				sound41.play()
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
					if a>=1.4:
						sound41.stop()
			else:
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==42 :
			if voice == 1:
				sound42.play()
				st=time.time()
				a=0
				while (a<1.7):
					ed=time.time()
					a=ed-st
					if a>=1.7:
						sound42.stop
			else:
				st=time.time()
				a=0
				while (a<1.7):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==43 :
			if voice == 1:
				sound43.play()
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
					if a>=2.6:
						sound43.stop()
			else:
				st=time.time()
				a=0
				while (a<2.6):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==44 :
			if voice == 1:
				sound44.play()
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
					if a>=1.4:
						sound44.stop()
			else:
				st=time.time()
				a=0
				while (a<1.4):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==5 :
			if voice == 1:
				sound.play()
				st=time.time()
				a=0
				while (a<2):
					ed=time.time()
					a=ed-st
					if a>=2:
						sound.stop()
			else:
				st=time.time()
				a=0
				while (a<2):
					ed=time.time()
					a=ed-st
			Alarm.value = 0
			print(Alarm.value)
			
		if alarm ==91 :
			send_speed([-300,0,0],ser)
			xspeed.value=300
			yspeed.value=0
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
		
		if alarm ==92 :
			send_speed([300,0,0],ser)
			xspeed.value=-300
			yspeed.value=0
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
		
		if alarm ==93 :
			send_speed([0,-400,0],ser)
			xspeed.value=0
			yspeed.value=400
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==94 :
			send_speed([0,400,0],ser)
			xspeed.value=0
			yspeed.value=-400
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
				
		if alarm ==95 :
			send_speed([-200,0,0],ser)
			xspeed.value=200
			yspeed.value=0
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
		
		if alarm ==96 :
			send_speed([200,0,0],ser)
			xspeed.value=-200
			yspeed.value=0
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
		
		if alarm ==97 :
			send_speed([-0,-300,0],ser)
			xspeed.value=0
			yspeed.value=300
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)

		if alarm ==98 :
			send_speed([0,300,0],ser)
			xspeed.value=0
			yspeed.value=-300
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
			
		if alarm ==99 :
			send_speed([0,0,0],ser)
			xspeed.value=0
			yspeed.value=0
			zspeed.value=0
			Alarm.value = 0
			print(Alarm.value)
		
		if alarm ==910 :
			Alarm.value = 31
			print(Alarm.value)
		
		if alarm ==911 :
			Alarm.value = 32
			print(Alarm.value)

		if alarm ==912 :
			Alarm.value = 33
			print(Alarm.value)
