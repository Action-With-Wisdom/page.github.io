import tkinter as tk
from tkinter import StringVar
from PIL import Image, ImageTk

def face(Alarm, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position,sign,If_voice,If_drive,WtPrefer):
    global X
    global Y
    global Z
    global alarm
    global voice
    global drive
    global jump
    global prefer
    X = x_position.value*0.01
    Y = y_position.value*0.01
    Z = z_position.value*0.01
    alarm = Alarm.value
    voice = If_voice.value
    drive = If_drive.value
    jump = 1
    prefer = WtPrefer.value

    # 函数：更新图片位置
    def update_image_position(x, y):
        canvas.coords(image_item, x, y)  # 更新图片位置

    # 定时改变图片位置
    def update_position_periodically():
        global initial_x, initial_y
        X = x_position.value*0.01
        Y = y_position.value*0.01
        Z = z_position.value*0.01
        new_x = initial_x+X  # x方向坐标
        new_y = initial_y+Y  # y方向坐标
        update_image_position(new_x, new_y)
        root.after(10, update_position_periodically)  # 每0.01秒（10毫秒）更新一次位置

    # 复选框功能：语音提醒
    def voice_reminder_changed():
        voice = voice_reminder_var.get()
        If_voice.value = int(voice)
        print("语音提醒:", If_voice.value)

    # 复选框功能：弹窗提醒
    # 弹窗提醒变量变化时触发弹窗显示
    def popup_reminder_changed():
        jump=popup_reminder_var.get()
        print("弹窗提醒:", jump)

    # 复选框功能：驾驶辅助
    def driver_assist_changed():
        drive = driver_assist_var.get()
        If_drive.value = int(drive)
        print("驾驶辅助:", If_drive.value)

    # 下拉菜单功能：车速设置
    def speed_mode_changed(event):
        mode=speed_mode_var.get()
        if mode == "优先减速":
            prefer = 1
        elif mode == "优先停车":
            prefer = 0
        WtPrefer.value = prefer
        print("车速设置:", speed_mode_var.get())
        print("WtPrefer:", WtPrefer.value)


    # 弹窗功能函数
    def show_alert_popup():
        alert_level = Alarm.value
        popup_text = ""

        if alert_level == 6:
            popup_text = "智多行为您保驾护航"
        elif alert_level == 11:
            popup_text = "即将与前车碰撞！"
        elif alert_level == 12:
            popup_text = "请注意正后方来车！"
        elif alert_level == 2:
            popup_text = "请注意路口横向来车！"
        elif alert_level == 31:
            popup_text = "前方路口可以通行！"
        elif alert_level == 32:
            popup_text = "前方路口红灯，请减速！"
        elif alert_level == 33:
            popup_text = "闯红灯预警，请立即停车！"
        elif alert_level == 41:
            popup_text = "注意后方车辆变道！"
        elif alert_level == 42:
            popup_text = "注意侧后方车辆超车！"
        elif alert_level == 43:
            popup_text = "注意侧后方盲区来车！"
        elif alert_level == 44:
            popup_text = "车道线偏离预警！"
        else:
            popup_text = "预警级别出错，请重启程序！"

        # 获取屏幕宽度和高度
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        if alert_level != 0:
            popup = tk.Toplevel()
            popup.attributes("-alpha", 0.7)  # 设置弹窗半透明
            popup.title("预警弹窗")
            # 设置窗口大小为屏幕大小的 90%
            popup.geometry(f"{int(screen_width * 0.2)}x{int(screen_height * 0.1)}")
            # 将窗口放置在屏幕中央
            popup.geometry("+{}+{}".format(int(screen_width * 0.40), int(screen_height * 0.45)))
            label = tk.Label(popup, text=popup_text, font=("Arial", 12))
            label.pack(padx=20, pady=10)

            # 弹窗持续两秒
            popup.after(2000, popup.destroy)

    # 实时监测预警变量变化
    def check_alert_var():
        current_alert_level = Alarm.value
        jump = popup_reminder_var.get()
        if current_alert_level != "0":
            if jump != "0":
                show_alert_popup()

        root.after(1000, check_alert_var)  # 每秒检查一次预警变量


    def draw_gradient_circle(canvas, x, y, radius, color):
        for i in range(radius, 0, -1):
            r = hex(min(255, 255-int((255-color[0]) * i / radius)))[2:].zfill(2)
            g = hex(min(255, 255-int((255-color[1]) * i / radius)))[2:].zfill(2)
            b = hex(min(255, 255-int((255-color[2]) * i / radius)))[2:].zfill(2)
            rgb_color = f"#{r}{g}{b}"
            canvas.create_oval(x - i, y - i, x + i, y + i, outline=rgb_color)
	
    # 定义控制小车行进的函数
    def fast1(event=None):
        Alarm.value=91

    def fast2(event=None):
        Alarm.value=92

    def fast3(event=None):
        Alarm.value=93

    def fast4(event=None):
        Alarm.value=94

    def move_forward(event=None):
        Alarm.value=95

    def move_backward(event=None):
        Alarm.value=96

    def move_left(event=None):
        Alarm.value=97

    def move_right(event=None):
        Alarm.value=98

    def stop_car(event=None):
        Alarm.value=99

    def bobao1(event=None):
        Alarm.value=910

    def bobao2(event=None):
        Alarm.value=911

    def bobao3(event=None):
        Alarm.value=912



    # 创建窗口
    root = tk.Tk()
    root.title("Dynamic Image Display")

    # 设置窗口全屏显示
    root.attributes('-fullscreen', True)

    root.bind('<Up>', fast1)
    root.bind('<Down>', fast2)
    root.bind('<Left>', fast3)
    root.bind('<Right>', fast4)
    root.bind('<w>', move_forward)
    root.bind('<s>', move_backward)
    root.bind('<a>', move_left)
    root.bind('<d>', move_right)
    root.bind('<space>', stop_car)
    root.bind('<c>', bobao1)
    root.bind('<v>', bobao2)
    root.bind('<b>', bobao3)

    # 初始图片位置
    global initial_x
    global initial_y

    initial_x = -530
    initial_y = -3000

    # 打开图片文件
    image = Image.open("example.jpg")
    image = image.resize((3720, 3896))  # 将图片放大为400x400

    # 获取屏幕宽度和高度
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()

    canvas_width=int(screen_width * 1)
    canvas_height=int(screen_height * 1)

    # 创建画布
    #canvas = tk.Canvas(root, width=image.width, height=image.height)
    canvas = tk.Canvas(root, width=canvas_width, height=canvas_height)
    canvas.pack()

    # 在画布上显示图片
    img_tk = ImageTk.PhotoImage(image)
    image_item = canvas.create_image(initial_x, initial_y, anchor=tk.NW, image=img_tk)

    # 开始定时更新图片位置
    update_position_periodically()
    # 变量初始化
    voice_reminder_var = StringVar()
    voice_reminder_var.set("1")
    popup_reminder_var = StringVar()
    popup_reminder_var.set("1")  # 默认不显示弹窗
    driver_assist_var = StringVar()
    driver_assist_var.set("1")
    speed_mode_var = StringVar()
    speed_mode_var.set("优先减速")  # 默认选中优先车速

    # 创建复选框
    voice_reminder_checkbox = tk.Checkbutton(root, text="语音提醒", variable=voice_reminder_var, onvalue="1", offvalue="0", command=voice_reminder_changed)
    voice_reminder_checkbox.place(x=10, y=40)

    popup_reminder_checkbox = tk.Checkbutton(root, text="弹窗提醒", variable=popup_reminder_var, onvalue="1", offvalue="0", command=popup_reminder_changed)
    popup_reminder_checkbox.place(x=10, y=70)

    driver_assist_checkbox = tk.Checkbutton(root, text="驾驶辅助", variable=driver_assist_var, onvalue="1", offvalue="0", command=driver_assist_changed)
    driver_assist_checkbox.place(x=10, y=100)

    # 创建下拉菜单
    speed_mode_menu = tk.OptionMenu(root, speed_mode_var, "优先减速", "优先停车", command=speed_mode_changed)
    speed_mode_menu.place(x=10, y=130)

    # 开始实时监测预警变量变化
    check_alert_var()

    # 设置圆形参数
    center_x = canvas_width // 2
    center_y = canvas_height // 6*5
    radius = min(canvas_width, canvas_height) // 25
    blue_color = (0, 110, 255)  # RGB值，这里是蓝色

    # 绘制渐变圆形
    draw_gradient_circle(canvas, center_x, center_y, radius, blue_color)
    # 运行窗口
    root.mainloop()

def facepro(Alarm, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position,xspeed,yspeed,zspeed,sign,If_voice,If_drive,WtPrefer):
    global X
    global Y
    global Z
    global alarm
    global voice
    global drive
    global jump
    global prefer
    X = yspeed.value*0.01*0.5*0.5
    Y = xspeed.value*0.01*0.5
    Z = zspeed.value*0.01*0.5
    alarm = Alarm.value
    voice = If_voice.value
    drive = If_drive.value
    jump = 1
    prefer = WtPrefer.value

    # 函数：更新图片位置
    def update_image_position(x, y):
        canvas.coords(image_item, x, y)  # 更新图片位置

    # 定时改变图片位置
    def update_position_periodically():
        global initial_x, initial_y
        X = yspeed.value*0.01*0.5*0.5
        Y = xspeed.value*0.01*0.5
        Z = zspeed.value*0.01*0.5
        new_x = initial_x+X  # x方向坐标
        new_y = initial_y+Y  # y方向坐标
        initial_x = new_x
        initial_y = new_y
        update_image_position(new_x, new_y)
        root.after(10, update_position_periodically)  # 每0.01秒（10毫秒）更新一次位置

    # 复选框功能：语音提醒
    def voice_reminder_changed():
        voice = voice_reminder_var.get()
        If_voice.value = int(voice)
        print("语音提醒:", If_voice.value)

    # 复选框功能：弹窗提醒
    # 弹窗提醒变量变化时触发弹窗显示
    def popup_reminder_changed():
        jump=popup_reminder_var.get()
        print("弹窗提醒:", jump)

    # 复选框功能：驾驶辅助
    def driver_assist_changed():
        drive = driver_assist_var.get()
        If_drive.value = int(drive)
        print("驾驶辅助:", If_drive.value)

    # 下拉菜单功能：车速设置
    def speed_mode_changed(event):
        mode=speed_mode_var.get()
        if mode == "优先减速":
            prefer = 1
        elif mode == "优先停车":
            prefer = 0
        WtPrefer.value = prefer
        print("车速设置:", speed_mode_var.get())
        print("WtPrefer:", WtPrefer.value)


    # 弹窗功能函数
    def show_alert_popup():
        alert_level = Alarm.value
        popup_text = ""

        if alert_level == 6:
            popup_text = "智多行为您保驾护航"
        elif alert_level == 11:
            popup_text = "即将与前车碰撞！"
        elif alert_level == 12:
            popup_text = "请注意正后方来车！"
        elif alert_level == 2:
            popup_text = "请注意路口横向来车！"
        elif alert_level == 31:
            popup_text = "前方路口可以通行！"
        elif alert_level == 32:
            popup_text = "前方路口红灯，请减速！"
        elif alert_level == 33:
            popup_text = "闯红灯预警，请立即停车！"
        elif alert_level == 41:
            popup_text = "注意后方车辆变道！"
        elif alert_level == 42:
            popup_text = "注意侧后方车辆超车！"
        elif alert_level == 43:
            popup_text = "注意侧后方盲区来车！"
        elif alert_level == 44:
            popup_text = "车道线偏离预警！"
        else:
            popup_text = "预警级别出错，请重启程序！"

        # 获取屏幕宽度和高度
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()

        if alert_level != 0:
            popup = tk.Toplevel()
            popup.attributes("-alpha", 0.7)  # 设置弹窗半透明
            popup.title("预警弹窗")
            # 设置窗口大小为屏幕大小的 90%
            popup.geometry(f"{int(screen_width * 0.2)}x{int(screen_height * 0.1)}")
            # 将窗口放置在屏幕中央
            popup.geometry("+{}+{}".format(int(screen_width * 0.40), int(screen_height * 0.45)))
            label = tk.Label(popup, text=popup_text, font=("Arial", 12))
            label.pack(padx=20, pady=10)

            # 弹窗持续两秒
            popup.after(2000, popup.destroy)

    # 实时监测预警变量变化
    def check_alert_var():
        current_alert_level = Alarm.value
        jump = popup_reminder_var.get()
        if current_alert_level != "0":
            if jump != "0":
                show_alert_popup()

        root.after(1000, check_alert_var)  # 每秒检查一次预警变量


    def draw_gradient_circle(canvas, x, y, radius, color):
        for i in range(radius, 0, -1):
            r = hex(min(255, 255-int((255-color[0]) * i / radius)))[2:].zfill(2)
            g = hex(min(255, 255-int((255-color[1]) * i / radius)))[2:].zfill(2)
            b = hex(min(255, 255-int((255-color[2]) * i / radius)))[2:].zfill(2)
            rgb_color = f"#{r}{g}{b}"
            canvas.create_oval(x - i, y - i, x + i, y + i, outline=rgb_color)
	
    # 定义控制小车行进的函数
    def fast1(event=None):
        Alarm.value=91

    def fast2(event=None):
        Alarm.value=92

    def fast3(event=None):
        Alarm.value=93

    def fast4(event=None):
        Alarm.value=94

    def move_forward(event=None):
        Alarm.value=95

    def move_backward(event=None):
        Alarm.value=96

    def move_left(event=None):
        Alarm.value=97

    def move_right(event=None):
        Alarm.value=98

    def stop_car(event=None):
        Alarm.value=99

    def bobao1(event=None):
        Alarm.value=910

    def bobao2(event=None):
        Alarm.value=911

    def bobao3(event=None):
        Alarm.value=912



    # 创建窗口
    root = tk.Tk()
    root.title("Dynamic Image Display")

    # 设置窗口全屏显示
    root.attributes('-fullscreen', True)

    root.bind('<Up>', fast1)
    root.bind('<Down>', fast2)
    root.bind('<Left>', fast3)
    root.bind('<Right>', fast4)
    root.bind('<w>', move_forward)
    root.bind('<s>', move_backward)
    root.bind('<a>', move_left)
    root.bind('<d>', move_right)
    root.bind('<space>', stop_car)
    root.bind('<c>', bobao1)
    root.bind('<v>', bobao2)
    root.bind('<b>', bobao3)

    # 初始图片位置
    global initial_x
    global initial_y

    initial_x = -530
    initial_y = -3000

    # 打开图片文件
    image = Image.open("example.jpg")
    image = image.resize((3720, 3896))  # 将图片放大为400x400

    # 获取屏幕宽度和高度
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()

    canvas_width=int(screen_width * 1)
    canvas_height=int(screen_height * 1)

    # 创建画布
    #canvas = tk.Canvas(root, width=image.width, height=image.height)
    canvas = tk.Canvas(root, width=canvas_width, height=canvas_height)
    canvas.pack()

    # 在画布上显示图片
    img_tk = ImageTk.PhotoImage(image)
    image_item = canvas.create_image(initial_x, initial_y, anchor=tk.NW, image=img_tk)

    # 开始定时更新图片位置
    update_position_periodically()
    # 变量初始化
    voice_reminder_var = StringVar()
    voice_reminder_var.set("1")
    popup_reminder_var = StringVar()
    popup_reminder_var.set("1")  # 默认不显示弹窗
    driver_assist_var = StringVar()
    driver_assist_var.set("1")
    speed_mode_var = StringVar()
    speed_mode_var.set("优先减速")  # 默认选中优先车速

    # 创建复选框
    voice_reminder_checkbox = tk.Checkbutton(root, text="语音提醒", variable=voice_reminder_var, onvalue="1", offvalue="0", command=voice_reminder_changed)
    voice_reminder_checkbox.place(x=10, y=40)

    popup_reminder_checkbox = tk.Checkbutton(root, text="弹窗提醒", variable=popup_reminder_var, onvalue="1", offvalue="0", command=popup_reminder_changed)
    popup_reminder_checkbox.place(x=10, y=70)

    driver_assist_checkbox = tk.Checkbutton(root, text="驾驶辅助", variable=driver_assist_var, onvalue="1", offvalue="0", command=driver_assist_changed)
    driver_assist_checkbox.place(x=10, y=100)

    # 创建下拉菜单
    speed_mode_menu = tk.OptionMenu(root, speed_mode_var, "优先减速", "优先停车", command=speed_mode_changed)
    speed_mode_menu.place(x=10, y=130)

    # 开始实时监测预警变量变化
    check_alert_var()

    # 设置圆形参数
    center_x = canvas_width // 2
    center_y = canvas_height // 6*5
    radius = min(canvas_width, canvas_height) // 25
    blue_color = (0, 110, 255)  # RGB值，这里是蓝色

    # 绘制渐变圆形
    draw_gradient_circle(canvas, center_x, center_y, radius, blue_color)
    # 运行窗口
    root.mainloop()

