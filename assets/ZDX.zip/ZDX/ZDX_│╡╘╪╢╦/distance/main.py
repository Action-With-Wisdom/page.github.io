import RPi.GPIO as GPIO
import time
import numpy as np
import serial
import binascii

#超声波函数
def Distance():
    GPIO.output(TrigPin,GPIO.LOW)
    time.sleep(0.000002)
    GPIO.output(TrigPin,GPIO.HIGH)
    time.sleep(0.000015)
    GPIO.output(TrigPin,GPIO.LOW)

    t3 = time.time()

    while not GPIO.input(EchoPin):
        t4 = time.time()
        if (t4 - t3) > 0.03 :
            return -1
    t1 = time.time()
    while GPIO.input(EchoPin):
        t5 = time.time()
        if(t5 - t1) > 0.03 :
            return -1

    t2 = time.time()
    time.sleep(0.01)
    #print ("distance_1 is %d " % (((t2 - t1)* 340 / 2) * 100))
    return ((t2 - t1)* 340 / 2) * 100

def Distance_test():
    num = 0
    ultrasonic = []
    while num < 5:
            distance = Distance()
            #print("distance is %f"%(distance) )
            while int(distance) == -1 :
                distance = Distance()
                #print("Tdistance is %f"%(distance) )
            while (int(distance) >= 500 or int(distance) == 0) :
                distance = Distance()
                #print("Edistance is %f"%(distance) )
            ultrasonic.append(distance)
            num = num + 1
            #time.sleep(0.01)
    distance = (ultrasonic[1] + ultrasonic[2] + ultrasonic[3])/3
    #print("distance is %f"%(distance) ) 
    return distance

GPIO.setwarnings(False)

EchoPin = 18
TrigPin = 16

#设置GPIO口为BCM编码方式
GPIO.setmode(GPIO.BOARD)
GPIO.setup(EchoPin,GPIO.IN)
GPIO.setup(TrigPin,GPIO.OUT)    


def ct(If_distance, Alarm):
	If_distance.value = 1
	count = 0
	lower_bound = 15
	upper_bound = 20
	try:
		while True:
			distance = Distance_test()
			# 如果输入在区间内
			if lower_bound <= distance <= upper_bound:
				count += 1
			else:
				count = 0  # 重置计数器
        
			# 如果连续三次输入在区间内
			if count == 3:
				print("连续三次输入在区间 [{}, {}] 内".format(lower_bound, upper_bound))
				count = 0  # 重置计数器
				Alarm.value = 11
				print(Alarm.value) 
				time.sleep(1)  # 等待1秒再进行下一次测量
			time.sleep(0.01)
	except KeyboardInterrupt:
		pass
	print("Ending")
	GPIO.cleanup
	
def cl(a):
    dat1 = a

    if dat1 == 'a':
        dat1 = 10
    elif dat1 == 'b':
        dat1 = 11
    elif dat1 == 'c':
        dat1 = 12
    elif dat1 == 'd':
        dat1 = 13
    elif dat1 == 'e':
        dat1 = 14
    elif dat1 == 'f':
        dat1 = 15
        
    return dat1

def TOF(If_distance, Alarm):
    global serial1
    serial1 = serial.Serial('/dev/ttyAMA0',115200)
    if serial1.isOpen() :
        print("open success")
    else :
        print("open failed")
    If_distance.value = 1
    count = 0
    lower_bound = 150
    upper_bound = 200
    while True:     
        time.sleep(0.1) 
        num=serial1.inWaiting()               
        if num: 
            try:   #如果读取的不是十六进制数据--
                data= str(binascii.b2a_hex(serial1.read(num))) #十六进制显示方法2
                if(len(data)>8):
                    #print(data)
                    dat1 = int(cl(data[8]))
                    dat2 = int(cl(data[9]))
                    dat3 = int(cl(data[10]))
                    dat4 = int(cl(data[11]))
                    distance = (((dat1 * 16) + dat2) * 256) + ((dat3 * 16) + dat4)
                    #print(distance)
                    print("distance is %f mm"%(distance))
                    # 如果输入在区间内
                    if lower_bound <= distance <= upper_bound:
                        count += 1
                    else:
                        count = 0  # 重置计数器                
                    # 如果连续三次输入在区间内
                    if count == 1:
                        print("连续三次输入在区间 [{}, {}] 内".format(lower_bound, upper_bound))
                        count = 0  # 重置计数器
                        Alarm.value = 11
                        print(Alarm.value) 
                        time.sleep(1)  # 等待1秒再进行下一次测量
            except: #--则将其作为字符串读取
                pass
