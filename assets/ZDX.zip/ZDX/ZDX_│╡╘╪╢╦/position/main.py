import smbus            # 导入I2C的SMBus模块
from time import sleep  # 导入sleep函数
import numpy as np
import time



# MPU6050的一些寄存器及其地址
PWR_MGMT_1   = 0x6B
SMPLRT_DIV   = 0x19
CONFIG       = 0x1A
GYRO_CONFIG  = 0x1B
INT_ENABLE   = 0x38
ACCEL_XOUT_H = 0x3B
ACCEL_YOUT_H = 0x3D
ACCEL_ZOUT_H = 0x3F
GYRO_XOUT_H  = 0x43
GYRO_YOUT_H  = 0x45
GYRO_ZOUT_H  = 0x47

def MPU_Init():
    # 写入采样率寄存器
    bus.write_byte_data(Device_Address, SMPLRT_DIV, 7)
    
    # 写入电源管理寄存器
    bus.write_byte_data(Device_Address, PWR_MGMT_1, 1)
    
    # 写入配置寄存器
    bus.write_byte_data(Device_Address, CONFIG, 0)
    
    # 写入陀螺仪配置寄存器
    bus.write_byte_data(Device_Address, GYRO_CONFIG, 24)
    
    # 写入中断使能寄存器
    bus.write_byte_data(Device_Address, INT_ENABLE, 1)

def read_raw_data(addr):
    # 加速度计和陀螺仪的值是16位的
    high = bus.read_byte_data(Device_Address, addr)
    low = bus.read_byte_data(Device_Address, addr+1)
    
    # 合并高位和低位的值
    value = ((high << 8) | low)
    
    # 获取MPU6050的有符号值
    if(value > 32768):
        value = value - 65536
    return value

bus = smbus.SMBus(1)    # 对于旧版本的树莓派板，可以使用bus = smbus.SMBus(0)
Device_Address = 0x68   # MPU6050设备地址

MPU_Init()
	
print("读取陀螺仪和加速度计数据")
    
def mpu6050(If_position, x_a,y_a,z_a,x_v,y_v,z_v,x_position,y_position,z_position):
	

	# 初始化速度和位移
	Vx = 0
	Vy = 0
	Vz = 0
	X = 0
	Y = 0
	Z = 0

	st=time.time()
	a=0

	ax = []
	ay = []
	az = []

	gx = []
	gy = []
	gz = []

	while a<10:
		ed=time.time()
		a=ed-st
		# 读取加速度计的原始值
		acc_x = read_raw_data(ACCEL_XOUT_H)
		acc_y = read_raw_data(ACCEL_YOUT_H)
		acc_z = read_raw_data(ACCEL_ZOUT_H)
    
		# 读取陀螺仪的原始值
		gyro_x = read_raw_data(GYRO_XOUT_H)
		gyro_y = read_raw_data(GYRO_YOUT_H)
		gyro_z = read_raw_data(GYRO_ZOUT_H)
    
		# 根据灵敏度比例因子将值转换为实际值
		Ax = acc_x / 16384.0 
		Ay = acc_y / 16384.0 
		Az = acc_z / 16384.0 
    
		Gx = gyro_x / 131.0 
		Gy = gyro_y / 131.0 
		Gz = gyro_z / 131.0
    
		ax.append(Ax)
		ay.append(Ay)
		az.append(Az)
    
		gx.append(Gx)
		gy.append(Gy)
		gz.append(Gz)
		sleep(0.01)
    
    

	axmean = np.mean(ax)
	aymean = np.mean(ay)
	azmean = np.mean(az)

	gxmean = np.mean(gx)
	gymean = np.mean(gy)
	gzmean = np.mean(gz)

	while True:
		#If_position.value = 1
		# 读取加速度计的原始值
		acc_x = read_raw_data(ACCEL_XOUT_H)
		acc_y = read_raw_data(ACCEL_YOUT_H)
		acc_z = read_raw_data(ACCEL_ZOUT_H)
    
		# 读取陀螺仪的原始值
		gyro_x = read_raw_data(GYRO_XOUT_H)
		gyro_y = read_raw_data(GYRO_YOUT_H)
		gyro_z = read_raw_data(GYRO_ZOUT_H)
    
		# 根据灵敏度比例因子将值转换为实际值
		Ax = acc_x / 16384.0 - axmean
		Ay = acc_y / 16384.0 - aymean
		Az = acc_z / 16384.0 - azmean
    
		Gx = gyro_x / 131.0 - gxmean
		Gy = gyro_y / 131.0 - gymean
		Gz = gyro_z / 131.0 - gzmean
		
		# 如果值在-0.03到0.03之间，则设为0
		if -0.03 < Ax < 0.03:
			Ax = 0
		if -0.03 < Ay < 0.03:
			Ay = 0
		if -0.03 < Az < 0.03:
			Az = 0
		if -0.03 < Gx < 0.03:
			Gx = 0
		if -0.03 < Gy < 0.03:
			Gy = 0
		if -0.03 < Gz < 0.03:
			Gz = 0
        
		Vx += Ax * 100
		Vy += Ay * 100
		Vz += Az * 100
    
		X += Vx 
		Y += Vy 
		Z += Vz 
		
		XA=int(Ax*100)
		YA=int(Ay*100)
		ZA=int(Az*100)
		
		XV=int(Vx)
		YV=int(Vy)
		ZV=int(Vz)

		XP=int(X)
		YP=int(Y)
		ZP=int(Z)
		
		x_a.value = XA
		y_a.value = YA
		z_a.value = ZA
		
		x_v.value = XV
		y_v.value = YV
		z_v.value = ZV
		
		x_position.value = XP
		y_position.value = YP
		z_position.value = ZP
		
		#print("X=%.2f m" % X, "\tY=%.2f m" % Y, "\tZ=%.2f m" % Z)   
 
		#print("Gx=%.2f" % Gx, u'\u00b0' + "/s", "\tGy=%.2f" % Gy, u'\u00b0' + "/s", "\tGz=%.2f" % Gz, u'\u00b0' + "/s", "\tAx=%.2f g" % Ax, "\tAy=%.2f g" % Ay, "\tAz=%.2f g" % Az)   
		sleep(0.01)
