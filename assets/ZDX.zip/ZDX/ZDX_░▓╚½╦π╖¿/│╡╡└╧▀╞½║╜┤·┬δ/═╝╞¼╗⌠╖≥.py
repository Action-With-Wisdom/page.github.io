import random
import cv2
import numpy as np

IMG_WIDTH = 700
IMG_HEIGHT = 400


def show_img(name, img):
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.imshow(name, img)
    cv2.resizeWindow(name, IMG_WIDTH, IMG_HEIGHT)


# 计算line的斜率
def calc_slope(line):
    x1, y1, x2, y2 = line[0]
    slope = (y2 - y1) / (x2 - x1)
    return slope

img = cv2.imread('pic.png', cv2.IMREAD_COLOR)

# 使用高斯滤波去除噪音点
blureed_img = cv2.GaussianBlur(img, (5, 5), 1)

# 图片转换
gray_img = cv2.cvtColor(blureed_img, cv2.COLOR_BGR2GRAY)

# Canny边缘检测
edge_img = cv2.Canny(gray_img, 100, 200, 3)

# 霍夫曼变换
lines = cv2.HoughLinesP(edge_img, 1, np.pi / 180, 15, minLineLength=40, maxLineGap=20)

for line in lines:
    x1, y1, x2, y2 = line[0]
    if x1 == x2 or y1 == y2:
        continue
    slope = calc_slope(line)
    print(slope)
    if abs(slope) < 0.1 or abs(slope) > 1:
        continue
    color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
    cv2.line(img, (x1, y1), (x2, y2), color, 8)  # 在图像上绘制直线

    show_img('edge_img', edge_img)
    show_img('img', img)

while True:
    if cv2.waitKey(1) % 0xFF == ord(' '):
        break
cv2.destroyAllWindows()