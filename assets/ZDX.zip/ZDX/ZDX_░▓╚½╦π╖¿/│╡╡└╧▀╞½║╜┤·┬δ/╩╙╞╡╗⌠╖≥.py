import datetime
import os
import shutil

import cv2
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib

matplotlib.use('Agg')  # 明确指定使用Agg后端

IMG_WIDTH = 700
IMG_HEIGHT = 400


# 显示指定尺寸的窗口
def show_img(name, img):
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.imshow(name, img)
    cv2.resizeWindow(name, IMG_WIDTH, IMG_HEIGHT)


# 计算line的斜率
def calc_slope(line):
    x1, y1, x2, y2 = line[0]
    slope = (y2 - y1) / (x2 - x1)
    return slope


def add_lanes(img):
    global slope_data

    # 使用高斯滤波去除噪音点
    blurred_img = cv2.GaussianBlur(img, (5, 5), 1)

    # 图片灰度转换
    gray_img = cv2.cvtColor(blurred_img, cv2.COLOR_BGR2GRAY)

    # Canny边缘检测
    edge_img = cv2.Canny(gray_img, 200, 300, 3)

    # 创建ROI
    poly_pts = np.array([[[0, 550], [0, 877], [1321, 877], [1321, 550], [800, 430], [600, 430]]])
    mask = np.zeros_like(gray_img)
    cv2.fillPoly(mask, pts=poly_pts, color=255)
    img_mask = cv2.bitwise_and(edge_img, mask)

    # 霍夫曼变换
    lines = cv2.HoughLinesP(img_mask, 1, np.pi / 180, 15, minLineLength=40, maxLineGap=20)

    for line in lines:
        x1, y1, x2, y2 = line[0]
        if x1 == x2 or y1 == y2:
            continue
        slope = calc_slope(line)
        slope_data.append(slope)
        if abs(slope) < 0.22:
            continue
        color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        cv2.line(img, (x1, y1), (x2, y2), color, 6)  # 在图像上绘制直线

    return img


def fig_to_array(fig):
    fig.canvas.draw()
    return np.array(fig.canvas.renderer.buffer_rgba())


def save_slope_img(frame, slope_data, output_dir):
    current_time = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    output_path = f"{output_dir}/slope_{current_time}.jpg"

    global dir_flag
    if dir_flag:
        # 创建输出目录（如果不存在）
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(output_dir, "创建成功！")
        else:
            # 如果目录存在，则删除目录及其内容
            shutil.rmtree(output_dir)
            os.makedirs(output_dir)
            print(output_dir, "删除并重新创建成功！")
        dir_flag = False

    # 绘制散点图
    plt.figure(figsize=(6, 4))
    plt.scatter(range(len(slope_data)), slope_data, color='blue', marker='o')
    plt.title('Scatter Plot')
    plt.xlabel('Index')
    plt.ylabel('Value')
    plt.grid(True)
    scatter_img = fig_to_array(plt.gcf())
    plt.close('all')  # 关闭所有图形窗口

    # 调整另一张图片的大小以匹配散点图的大小
    pic_resized = cv2.resize(frame, (scatter_img.shape[1], scatter_img.shape[0]))

    # 调整颜色通道顺序
    scatter_img_bgr = cv2.cvtColor(scatter_img, cv2.COLOR_RGBA2BGR)
    # 拼接图像
    concat_img = np.concatenate((scatter_img_bgr, pic_resized), axis=1)
    # 储存拼接后的图像
    cv2.imwrite(output_path, concat_img)


if __name__ == '__main__':
    file = [
        '右偏+左偏_未出道 (online-video-cutter.com)',
        '左偏+右偏_未出道 (online-video-cutter.com)',
        '左偏出道 (online-video-cutter.com)',
        '左偏未出道 (online-video-cutter.com)',
        '右偏未出道 (online-video-cutter.com)'
    ]
    i = 0
    video = cv2.VideoCapture(file[i] + '.mp4')
    paused = False
    dir_flag = True  # 是否为第一次文件夹操作
    while video.isOpened():
        ret, frame = video.read()
        if frame is None:
            break
        if ret:
            if not paused:
                slope_data = []
                frame = add_lanes(frame)
                show_img('video', frame)
                # save_slope_img(frame, slope_data, f'output/video{i}')
            key = cv2.waitKey(30)
            if key & 0xFF == ord(' '):  # 按下空格键暂停/继续视频
                paused = not paused
                while paused:
                    key = cv2.waitKey(30)
                    if key & 0xFF == ord(' '):
                        paused = not paused
                    elif key & 0xFF == 27:  # 按下Esc键退出
                        break
            elif key & 0xFF == 27:  # 按下Esc键退出
                break
    video.release()
    cv2.destroyAllWindows()
