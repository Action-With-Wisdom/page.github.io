import cv2
import numpy as np
import random
from collections import deque

IMG_WIDTH = 700
IMG_HEIGHT = 400
left_window = deque()
right_window = deque()


# 显示指定尺寸的窗口
def show_img(name, img):
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.imshow(name, img)
    cv2.resizeWindow(name, IMG_WIDTH, IMG_HEIGHT)


# 车道线坐标移动平均
def moving_average(data, data_window, window_size):
    if len(data_window) == window_size:
        data_window.popleft()
    data_window.append(data)
    point1 = np.mean([array[0] for array in data_window], axis=0).astype(int)
    point2 = np.mean([array[1] for array in data_window], axis=0).astype(int)
    data_window[-1] = np.array([point1, point2])
    return data_window[-1]


# 计算line的斜率
def calc_slope(line):
    x1, y1, x2, y2 = line[0]
    slope = (y2 - y1) / (x2 - x1)
    return slope


# 离群值过滤
def remove_abnormal_lines(lines, threshold):
    slopes = [calc_slope(line) for line in lines]
    while len(lines) > 0:
        mean = np.mean(slopes)
        diff = [abs(x - mean) for x in slopes]
        idx = np.argmax(diff)
        if diff[idx] > threshold:
            slopes.pop(idx)
            lines.pop(idx)
        else:
            break
    return lines


# 最小二乘拟合
def least_squares_fit(lines):
    # x、y坐标降维
    x_coord = np.ravel([[line[0][0], line[0][2]] for line in lines])
    y_coord = np.ravel([[line[0][1], line[0][3]] for line in lines])
    # 直线拟合
    poly = np.polyfit(x_coord, y_coord, deg=1)
    # 计算坐标值
    pos_min = (np.min(x_coord), np.polyval(poly, np.min(x_coord)))
    pos_max = (np.max(x_coord), np.polyval(poly, np.max(x_coord)))
    return np.array([pos_min, pos_max], dtype=np.intp)


def draw_rectangle(img):
    height, width, _ = img.shape

    # 计算矩形的左上角和右下角坐标
    height -= 100
    width += 20
    rect_width = 150
    rect_height = 150
    top_left = (int(width / 2 - rect_width / 2), int(height / 2 - rect_height / 2))
    bottom_right = (int(width / 2 + rect_width / 2), int(height / 2 + rect_height / 2))
    cv2.rectangle(img, top_left, bottom_right, (255, 0, 0), 2)  # 矩形颜色为蓝色，线条宽度为2
    return top_left, bottom_right


def draw_text(img, text):
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 2
    font_color = (0, 0, 255)  # 蓝色
    thickness = 3
    text_size = cv2.getTextSize(text, font, font_scale, thickness)[0]
    text_x = int((img.shape[1] - text_size[0]) / 2)
    text_y = int((img.shape[0] + text_size[1]) / 2)
    cv2.putText(img, text, (text_x, text_y), font, font_scale, font_color, thickness)


def lines_intersection(line1, line2):
    x1, y1 = line1[0]
    x2, y2 = line1[1]
    x3, y3 = line2[0]
    x4, y4 = line2[1]
    # 直线的一般式：ax + by + c = 0
    a1, b1, c1 = -(y2 - y1), x2 - x1, (y2 - y1) * x1 - (x2 - x1) * y1
    a2, b2, c2 = -(y4 - y3), x4 - x3, (y4 - y3) * x3 - (x4 - x3) * y3
    r = False  # 是否相交
    x0, y0 = 0, 0  # 交点坐标
    # 判断相交
    if b1 == 0 and b2 != 0:
        r = True
    elif b1 != 0 and b2 == 0:
        r = True
    elif b1 != 0 and b2 != 0 and a1 / b1 != a2 / b2:
        r = True
    # 求交点
    if r:
        x0 = (b1 * c2 - b2 * c1) // (a1 * b2 - a2 * b1)
        y0 = (a1 * c2 - a2 * c1) // (a2 * b1 - a1 * b2)
    return x0, y0


def add_lanes(img):
    # 使用高斯滤波去除噪音点
    blurred_img = cv2.GaussianBlur(img, (5, 5), 1)

    # 图片灰度转换
    gray_img = cv2.cvtColor(blurred_img, cv2.COLOR_BGR2GRAY)

    # Canny边缘检测
    edge_img = cv2.Canny(gray_img, 200, 300)

    # 创建ROI
    poly_pts = np.array([[[0, 550], [0, 877], [1321, 877], [1321, 550], [800, 430], [600, 430]]])
    mask = np.zeros_like(gray_img)
    cv2.fillPoly(mask, pts=poly_pts, color=255)
    img_mask = cv2.bitwise_and(edge_img, mask)

    # 霍夫曼变换
    lines = cv2.HoughLinesP(img_mask, 1, np.pi / 180, 15, minLineLength=40, maxLineGap=20)

    if not isinstance(lines, np.ndarray):
        return img

    # 分类左右车道线
    right_lines, left_lines = [], []
    for line in lines:
        x1, y1, x2, y2 = line[0]
        if x1 == x2 or y1 == y2:
            continue
        slope = calc_slope(line)
        # 删除异常横向边
        if abs(slope) < 0.22:
            continue
        if slope < 0:
            # cv2.line(img, (x1, y1), (x2, y2), (0, 255, 0), 6)  # 在图像上绘制直线
            left_lines.append(line)
        else:
            # cv2.line(img, (x1, y1), (x2, y2), (0, 255, 255), 6)  # 在图像上绘制直线
            right_lines.append(line)

    # 离散值过滤
    right_lines = remove_abnormal_lines(right_lines, threshold=0.2)
    left_lines = remove_abnormal_lines(left_lines, threshold=0.2)

    # 最小二乘拟合 -- 判断是否存在足够line拟合
    left_exist, right_exist = True, True
    if len(left_lines) <= 1:
        left_exist = False
    if len(right_lines) <= 1:
        right_exist = False

    # 绘制车道线前对车道线做移动平均
    if left_exist:
        left_line = least_squares_fit(left_lines)
        # left_line = moving_average(left_line, left_window, 3)
        cv2.line(img, tuple(left_line[0]), tuple(left_line[1]), color=(0, 255, 0), thickness=5)
    if right_exist:
        right_line = least_squares_fit(right_lines)
        # right_line = moving_average(right_line, right_window, 3)
        cv2.line(img, tuple(right_line[0]), tuple(right_line[1]), color=(0, 255, 255), thickness=5)

    # 判断偏航
    top_left, bottom_right = draw_rectangle(img)

    # 若少一个车道线，则说明驶离了车道
    if left_exist == False or right_exist == False:
        draw_text(img, "OUT")
    else:
        # 否则判断两条车道线的交点是否在矩形框内
        x0, y0 = lines_intersection(left_line, right_line)
        cv2.circle(img, (x0, y0), 10, (0, 0, 255), -1)

        # 判断是否偏航
        if x0 < top_left[0]:
            draw_text(img, "right")
        if x0 > bottom_right[0]:
            draw_text(img, "left")

    return img


if __name__ == '__main__':
    file = [
        '右偏+左偏_未出道 (online-video-cutter.com)',
        '左偏+右偏_未出道 (online-video-cutter.com)',
        '左偏出道 (online-video-cutter.com)',
        '左偏未出道 (online-video-cutter.com)',
        '右偏未出道 (online-video-cutter.com)'
    ]
    i = 1
    video = cv2.VideoCapture(file[i] + '.mp4')

    # 视频的帧速率和大小
    frame_width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = int(video.get(cv2.CAP_PROP_FPS))

    # 视频写入器
    # out = cv2.VideoWriter(f'output/video_{i}.mp4', cv2.VideoWriter_fourcc(*'mp4v'), fps, (frame_width, frame_height))

    paused = False
    while video.isOpened():
        ret, frame = video.read()
        if frame is None:
            break
        if ret:
            if not paused:
                slope_data = []
                frame = add_lanes(frame)
                # out.write(frame)  # 将处理后的帧写入视频
                show_img('video', frame)
            key = cv2.waitKey(30)
            if key & 0xFF == ord(' '):  # 按下空格键暂停/继续视频
                paused = not paused
                while paused:
                    key = cv2.waitKey(30)
                    if key & 0xFF == ord(' '):
                        paused = not paused
                    elif key & 0xFF == 27:  # 按下Esc键退出
                        break
            elif key & 0xFF == 27:  # 按下Esc键退出
                break
    video.release()
    # out.release()  # 释放视频写入器
    cv2.destroyAllWindows()
