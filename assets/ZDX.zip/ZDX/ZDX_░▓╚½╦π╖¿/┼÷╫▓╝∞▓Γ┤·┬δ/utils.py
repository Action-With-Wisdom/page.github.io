import math
import random
import tkinter as tk
import matplotlib.pyplot as plt
from matplotlib import patches
from matplotlib.patches import Polygon as pltPolygon
from module import Polygon, CarPltModel


def get_rotated_points(center_x, center_y, theta=0, width=6, height=10):
    """
    根据多边形偏转角度，获取旋转后的顶点坐标
    :param center_x: 中心点横坐标
    :param center_y: 中心点横坐标
    :param theta: 偏转角度（角度制）
    :param width: 矩形框的宽度，默认为6
    :param height: 矩形框的长度，默认为10
    :return: 旋转后的顶点坐标 (list)
    """
    top_left = (center_x - width / 2, center_y + height / 2)
    bottom_left = (center_x - width / 2, center_y - height / 2)
    bottom_right = (center_x + width / 2, center_y - height / 2)
    top_right = (center_x + width / 2, center_y + height / 2)

    # 获取旋转坐标 - 角度转弧度
    rad = math.pi * theta / 180
    sina = -math.sin(rad)
    cosa = math.cos(rad)

    rotated_top_left = (
        center_x + (top_left[0] - center_x) * cosa + (top_left[1] - center_y) * sina,
        center_y + (top_left[0] - center_x) * sina - (top_left[1] - center_y) * cosa
    )
    rotated_top_right = (
        center_x + (top_right[0] - center_x) * cosa + (top_right[1] - center_y) * sina,
        center_y + (top_right[0] - center_x) * sina - (top_right[1] - center_y) * cosa
    )
    rotated_bottom_left = (
        center_x + (bottom_left[0] - center_x) * cosa + (bottom_left[1] - center_y) * sina,
        center_y + (bottom_left[0] - center_x) * sina - (bottom_left[1] - center_y) * cosa
    )
    rotated_bottom_right = (
        center_x + (bottom_right[0] - center_x) * cosa + (bottom_right[1] - center_y) * sina,
        center_y + (bottom_right[0] - center_x) * sina - (bottom_right[1] - center_y) * cosa
    )

    return [rotated_top_left, rotated_bottom_left, rotated_bottom_right, rotated_top_right]


def plt_rectangle(*polygons):
    """
    绘制多个polygon对象
    :param polygons: 可传入多个polygon对象
    :return:
    """

    def plot_polygon(polygon, color):
        plt.gca().add_patch(pltPolygon(polygon.points, closed=True, fill=None, edgecolor=color))
        plt.plot(*zip(*(polygon.points + [polygon.points[0]])), color=color)  # 绘制多边形边框
        plt.scatter(polygon.center_x, polygon.center_y, color=color, s=20)  # 绘制中心坐标点

        # 计算箭头的终点坐标
        arrow_length = 2
        arrow_end_x = polygon.center_x + arrow_length * math.sin(math.pi * polygon.theta / 180)
        arrow_end_y = polygon.center_y + arrow_length * math.cos(math.pi * polygon.theta / 180)

        # 绘制箭头
        plt.arrow(polygon.center_x, polygon.center_y, arrow_end_x - polygon.center_x, arrow_end_y - polygon.center_y,
                  color=color, head_width=0.15, head_length=0.15, linewidth=1.5)

    def random_color():
        return (random.random(), random.random(), random.random())

    # 绘制多边形
    for polygon in polygons:
        color = random_color()
        plot_polygon(polygon, color)

    # 显示图形
    plt.gca().set_aspect('equal', adjustable='box')
    plt.show()


def dot_product(v1, v2):
    return v1[0] * v2[0] + v1[1] * v2[1]


def subtract(v1, v2):
    return [v1[0] - v2[0], v1[1] - v2[1]]


def normal_vector(v):
    return [-v[1], v[0]]


def is_overlap(min1, max1, min2, max2):
    return (min1 <= max2 and max1 >= min2) or (min2 <= max1 and max2 >= min1)


def poly_vs_poly(p1, p2):
    """
    判断两个多边形是否有交点
    :param p1: Polygon对象
    :param p2: Polygon对象
    :return: True or False
    """
    # 检测 p1 的所有法线
    for i in range(len(p1.points)):
        edge = subtract(p1.points[(i + 1) % len(p1.points)], p1.points[i])
        axis = normal_vector(edge)

        # 计算投影
        min1 = max1 = dot_product(p1.points[0], axis)
        for j in range(1, len(p1.points)):
            projection = dot_product(p1.points[j], axis)
            min1 = min(min1, projection)
            max1 = max(max1, projection)

        min2 = max2 = dot_product(p2.points[0], axis)
        for k in range(1, len(p2.points)):
            projection = dot_product(p2.points[k], axis)
            min2 = min(min2, projection)
            max2 = max(max2, projection)

        if not is_overlap(min1, max1, min2, max2):
            return False

    # 检测 p2 的所有法线
    for i in range(len(p2.points)):
        edge = subtract(p2.points[(i + 1) % len(p2.points)], p2.points[i])
        axis = normal_vector(edge)

        # 计算投影
        min1 = max1 = dot_product(p1.points[0], axis)
        for j in range(1, len(p1.points)):
            projection = dot_product(p1.points[j], axis)
            min1 = min(min1, projection)
            max1 = max(max1, projection)

        min2 = max2 = dot_product(p2.points[0], axis)
        for k in range(1, len(p2.points)):
            projection = dot_product(p2.points[k], axis)
            min2 = min(min2, projection)
            max2 = max(max2, projection)

        if not is_overlap(min1, max1, min2, max2):
            return False

    return True  # 所有法线上的投影都重叠，则两多边形相交


def create_car_obb(car):
    """
    获取Car对象的obb包络，即Polygon对象
    :param car: Car对象
    :return: 对应Car对象的Polygon对象
    """
    # 获取car对象的obb包络的顶点坐标
    points = get_rotated_points(car.pos_x, car.pos_y, car.heading_angle)
    # 创建Polygon对象用于图形绘制
    polygon = Polygon(points, car.pos_x, car.pos_y, car.heading_angle)
    return polygon


def create_car_plt_model(polygon, vel=1):
    """
    获取Polygon对象的plt绘制模型对象，即CarPltModel对象
    :param polygon: Polygon对象
    :param vel: 行驶速度，默认为1
    :return: 对应polygon对象的CarPltModel对象
    """

    def random_color():
        return (random.random(), random.random(), random.random())

    color = random_color()

    # 创建矩形对象
    rect = plt.Polygon(polygon.points, closed=True, fc='none', ec=color, lw=2)

    # 创建矩形中心点对象
    center = plt.Circle((polygon.center_x, polygon.center_y), 0.5, fc=color, ec='none')

    # 创建横向箭头对象
    # 计算箭头的终点坐标
    arrow_length = 10
    arrow_start_x = polygon.center_x
    arrow_start_y = polygon.center_y
    arrow_delta_x = arrow_length * math.sin(math.pi * polygon.theta / 180)
    arrow_delta_y = arrow_length * math.cos(math.pi * polygon.theta / 180)

    arrow = patches.FancyArrowPatch((arrow_start_x, arrow_start_y),
                                    (arrow_start_x + arrow_delta_x, arrow_start_y + arrow_delta_y),
                                    color=color,
                                    arrowstyle='->',
                                    linewidth=2, mutation_scale=8)
    return CarPltModel(rect, center, arrow, arrow_length, arrow_delta_x / arrow_length * vel, arrow_delta_y / arrow_length * vel,
                       polygon)

def collision_popup():
    """
    碰撞弹窗窗口
    :return:
    """
    root = tk.Tk()
    root.title("Collision Detected")

    # 获取屏幕尺寸
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()

    # 计算弹窗位置
    popup_width = 200
    popup_height = 100
    x = (screen_width - popup_width) // 2
    y = (screen_height - popup_height) // 2

    # 设置弹窗位置
    root.geometry(f"{popup_width}x{popup_height}+{x + 100}+{y - 100}")

    label = tk.Label(root, text="Collision Detected!")
    label.pack()

    def close_popup():
        root.destroy()

    button = tk.Button(root, text="Close", command=close_popup)
    button.pack()

    # 弹出窗口并暂停动画
    root.mainloop()


def frame_updata(plt_model):
    """
    动画的每帧更新函数，要求更新传入的CarPltModel对象及其父Polygon对象
    :param plt_model: CarPltModel对象
    :return: 更新后的CarPltModel对象的属性
    """
    rect = plt_model.rect
    center = plt_model.center
    arrow = plt_model.arrow
    arrow_length = plt_model.arrow_length
    x, y = plt_model.delta_x, plt_model.delta_y
    arrow_delta_x, arrow_delta_y = x * arrow_length, y * arrow_length

    # 更新矩形的顶点坐标
    current_vertices = rect.get_xy()
    new_vertices = [(vertex[0] + x, vertex[1] + y) for vertex in current_vertices]
    rect.set_xy(new_vertices)

    # 更新矩形中心点坐标
    current_center = center.get_center()
    new_center = (current_center[0] + x, current_center[1] + y)
    center.center = new_center

    # 更新箭头位置
    arrow.set_positions((new_center[0], new_center[1]),
                        (new_center[0] + arrow_delta_x, new_center[1] + arrow_delta_y))

    # 更新父Polygon对象
    plt_model.updata_polygon_info(new_vertices[:-1], new_center[0], new_center[1])

    return plt_model.rect, plt_model.center, plt_model.arrow