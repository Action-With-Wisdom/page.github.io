class Car:
    def __init__(self, x, y, heading_angle, width=6, length=10):
        """
        初始化汽车的基础信息
        :param x: 车辆初始横坐标 (float)
        :param y: 车辆初始纵坐标 (float)
        :param heading_angle: 车辆航向角（角度制）
        :param width: 车辆的宽度，默认值为6
        :param length: 车辆的长度，默认值为10
        """
        self.pos_x = x
        self.pos_y = y
        self.heading_angle = heading_angle  # 航向角（角度制）


class Polygon:
    def __init__(self, points, center_x, center_y, theta):
        """
        初始化车辆多边形的基础信息
        :param points: 多边形的顶点坐标 (list)
        :param center_x: 多边形的中心点横坐标 (float)
        :param center_y: 多边形的中心点纵坐标 (float)
        :param theta: 多边形的前进角度（角度制）
        """
        self.points = points
        self.center_x = center_x
        self.center_y = center_y
        self.theta = theta


class CarPltModel:
    def __init__(self, rect, center, arrow, arrow_length, delta_x, delta_y, polygon):
        """
        初始化多边形绘制对象的基本信息
        :param rect: 边框对象 (plt.Polygon)
        :param center: 中心点对象 (plt.Circle)
        :param arrow: 行驶方向箭头对象 (patches.FancyArrowPatch)
        :param arrow_length: 行驶方向箭头长度 (float)
        :param delta_x: 行驶方向的横轴单位长度 (float)
        :param delta_y: 行驶方向的纵轴单位长度 (float)
        :param polygon: 该绘制对象的父多边形 (Polygon)
        """
        self.rect = rect
        self.center = center
        self.arrow = arrow
        self.arrow_length = arrow_length
        self.delta_x = delta_x
        self.delta_y = delta_y
        self.polygon = polygon

    def updata_polygon_info(self, new_points, new_x, new_y):
        """
        更新父多边形的基本信息
        :param new_points: 新的顶点坐标 (list)
        :param new_x: 新的中心点横坐标 (float)
        :param new_y: 新的中心点纵坐标 (float)
        :return:
        """
        self.polygon.points = new_points
        self.polygon.center_x = new_x
        self.polygon.center_y = new_y
        # self.polygon.theta = new_theta
