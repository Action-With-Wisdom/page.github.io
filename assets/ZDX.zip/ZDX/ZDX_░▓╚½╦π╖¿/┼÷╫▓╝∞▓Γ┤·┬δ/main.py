import matplotlib
import numpy as np
from matplotlib import pyplot as plt, animation
from utils import *
from module import *

matplotlib.use('TkAgg')  # 使用TkAgg后端

# 创建图形和坐标轴
fig, ax = plt.subplots(figsize=(10, 6))
# 设置坐标轴范围
ax.set_xlim(0, 100)
ax.set_ylim(0, 100)

car1 = Car(40, 0, 0)
car2 = Car(100, 50, 270)
polygon1 = create_car_obb(car1)
polygon2 = create_car_obb(car2)

plt_models = []
plt_model1 = create_car_plt_model(polygon1)
plt_model2 = create_car_plt_model(polygon2, 1.7)
plt_models.append(plt_model1)
plt_models.append(plt_model2)

# 将需要绘制的plt对象加入ax
for plt_model in plt_models:
    ax.add_patch(plt_model.rect)
    ax.add_patch(plt_model.center)
    ax.add_patch(plt_model.arrow)


# 更新函数，每一帧调用一次
def update(frame):
    """

    :param frame:
    :return: 返回每帧需要更新的plt对象列表
    """
    objs = []

    for plt_model in plt_models:
        rect, center, arrow = frame_updata(plt_model)
        objs.extend([rect, center, arrow])

    # 每一帧，判断是否相撞
    if poly_vs_poly(polygon1, polygon2):
        collision_popup()
    else:
        print("没撞")

    return objs


# 创建动画
ani = animation.FuncAnimation(fig, update, frames=np.arange(100), interval=50, repeat=False)

# 显示动画
plt.gca().set_aspect('equal', adjustable='box')  # 保持纵横比例不失真
plt.show()
