class Car:
    def __init__(self, id, x, y):
        self.id = id
        self.x = x
        self.y = y
        self.radius = 5  # AOI探测半径

    def __str__(self):
        return f"<id: {self.id}, x: {self.x}, y: {self.y}>"

    def enter(self, obj):
        print(f"Car   {obj} enter {self} view")

    def leave(self, obj):
        print(f"Car   {obj} leave {self} view")

    def move(self, obj):
        print(f"Car    {obj} move in {self} view")


class SceneManager:
    def __init__(self):
        self.map_entity = {}
        self.list_x = []
        self.list_y = []

    def __str__(self):
        return f"Scene   list_x: {self.list_x}, list_y: {self.list_y}, entities: {self.map_entity.keys()}"

    def enter_entity(self, entity):
        # 实体添加到场景
        self.map_entity[entity.id] = entity

        # 查找横轴插入位置
        pos_x = len(self.list_x)
        for idx, id in enumerate(self.list_x):
            x = self.map_entity[id].x
            if entity.x < x:
                pos_x = idx
                break
        self.list_x.insert(pos_x, entity.id)

        # 查找纵轴插入位置
        pos_y = len(self.list_y)
        for idx, id in enumerate(self.list_y):
            y = self.map_entity[id].y
            if entity.y < y:
                pos_y = idx
                break
        self.list_y.insert(pos_y, entity.id)

        return entity

    def remove_entity(self, id):
        # 实体退出场景
        entity = self.map_entity.pop(id)

        # 实体退出横轴
        for idx, id in enumerate(self.list_x):
            if id == entity.id:
                del self.list_x[idx]
                break

        # 实体退出纵轴
        for idx, id in enumerate(self.list_y):
            if id == entity.id:
                del self.list_y[idx]
                break

    def get_aoi_entitis(self, entity):
        # 获取指定对象的aoi对象列表
        aoi_list = set([])
        for aoi_id in self.list_x:
            aoi_obj = self.map_entity[aoi_id]
            if abs(aoi_obj.x - entity.x) <= entity.radius:
                if aoi_obj != entity:
                    aoi_list.add(aoi_obj)

        for aoi_id in self.list_y:
            aoi_obj = self.map_entity[aoi_id]
            if abs(aoi_obj.y - entity.y) <= entity.radius:
                if aoi_obj != entity:
                    aoi_list.add(aoi_obj)
        return list(aoi_list)

    def update_pos(self, id, x, y):
        # 更新对象id的位置坐标
        if id not in self.map_entity.keys():
            # 首次进入: 实例化对象 - 添加对象 - 获取aoi范围内所有对象并通知id车辆进入
            entity = Car(id, x, y)
            entity = self.enter_entity(entity)
            aoi_objs = self.get_aoi_entitis(entity)
            for obj in aoi_objs:
                obj.enter(entity)
        else:
            entity = self.map_entity[id]
            # 移动出此场景: 获取aoi范围并通知id车辆退出 - 场景删除id车辆
            if x < 0 or y < 0:
                aoi_objs = self.get_aoi_entitis(entity)
                self.remove_entity(id)
                for obj in aoi_objs:
                    obj.leave(entity)
            else:
                # 在当前场景内移动: 获取旧的aoi范围并通知id车辆移动 - 删除旧的id车辆 - 新建新位置的id车辆并加入场景 - 获取新的aoi场景
                old_aoi_objs = self.get_aoi_entitis(entity)
                self.remove_entity(id)
                entity.x = x
                entity.y = y
                self.enter_entity(entity)
                new_aoi_objs = self.get_aoi_entitis(entity)
                # 对比新旧的aoi范围，对交集发送enter，对old-new发送leave，对new-old发送enter
                enter_objs = [obj for obj in new_aoi_objs if obj not in old_aoi_objs]
                leave_objs = [obj for obj in old_aoi_objs if obj not in new_aoi_objs]
                move_objs = [obj for obj in old_aoi_objs if obj in new_aoi_objs]
                for obj in enter_objs:
                    obj.enter(entity)
                for obj in leave_objs:
                    obj.leave(entity)
                for obj in move_objs:
                    obj.move(entity)


scene = SceneManager()
scene.update_pos(1, 1, 2)
scene.update_pos(2, 5, 9)
scene.update_pos(3, 4, 10)
print(scene)

car1 = scene.map_entity[1]
car2 = scene.map_entity[2]
car3 = scene.map_entity[3]

# 更新id = 1位置到(7, 7) - 获取aoi范围内所有车辆并通知
print('-' * 100)
print("更新id = 1位置到(7, 7) - 获取aoi范围内所有车辆并通知")
scene.update_pos(car1.id, 7, 7)
print(f"{car1} 的aoi范围车辆：")
for obj in scene.get_aoi_entitis(car1):
    print('\t\t\t\t\t\t\t\t', end='')
    print(obj)

# 更新id = 2位置到(1, 2) - 获取aoi范围内所有车辆并通知
print('-' * 100)
print("更新id = 2位置到(30, 24) - 获取aoi范围内所有车辆并通知")
scene.update_pos(car2.id, 30, 24)
print(f"{car2} 的aoi范围车辆：")
for obj in scene.get_aoi_entitis(car2):
    print('\t\t\t\t\t\t\t\t', end='')
    print(obj)

# 更新id = 3位置到(5, 5) - 获取aoi范围内所有车辆并通知
print('-' * 100)
print("更新id = 3位置到(5, 5) - 获取aoi范围内所有车辆并通知")
scene.update_pos(car3.id, 5, 5)
print(f"{car3} 的aoi范围车辆：")
for obj in scene.get_aoi_entitis(car3):
    print('\t\t\t\t\t\t\t\t', end='')
    print(obj)